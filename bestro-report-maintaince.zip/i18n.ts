
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      "common": {
        "save": "Save",
        "close": "Close",
        "back": "Back",
        "search": "Search",
        "loading": "Loading...",
        "status": "Status",
        "online": "Online",
        "offline": "Offline",
        "id": "ID",
        "normal": "Normal",
        "faulty": "Faulty"
      },
      "login": {
        "access_credentials": "Access Credentials",
        "email_placeholder": "email@bestro.com",
        "security_pin": "Security Pin",
        "forgot_pin": "Forgot?",
        "enter_terminal": "Enter Terminal",
        "register_new": "Register New Account",
        "failed_alert": "Failed: Invalid Email or PIN.",
        "identity_verification": "Identity Verification",
        "reset_pin": "Reset PIN",
        "staff_id": "Staff ID",
        "verify_identity": "Verify Identity",
        "save_new_pin": "Save New PIN",
        "pin_changed": "PIN successfully changed."
      },
      "fire_extinguisher": {
        "title": "FIRE EXTINGUISHER",
        "inventory_profile": "Inventory Profile",
        "inventory_summary": "Inventory Summary (Audit Ready)",
        "total_units": "Total Units",
        "system_desc": "Periodic inspection of portable fire extinguishers to ensure operational readiness and H13 Bomba certification compliance.",
        "desc_placeholder": "System description...",
        "asset_list": "Asset List",
        "add_unit": "Add Unit",
        "unit": "UNIT",
        "location_placeholder": "Unit Location...",
        "serial_label": "Serial No / Label",
        "agent_type": "Agent Type",
        "bomba_cert_expiry": "Bomba Cert Expiry (H13)",
        "mfg_year": "MFG Year",
        "cylinder_expiry": "Cylinder Expiry",
        "weight": "Weight (KG)",
        "pressure_level": "Pressure Level",
        "safety_pin": "Safety Pin",
        "physical_body": "Physical Body",
        "final_remarks": "Final Remarks & Service Photos",
        "commit_record": "Commit Technical Record",
        "remarks_placeholder": "Service summary...",
        "defect_placeholder": "Defect info...",
        "status": {
          "no_date": "NO DATE",
          "expired": "EXPIRED",
          "renew": "RENEW SOON",
          "valid": "CERT VALID",
          "cyl_expired": "CYLINDER EXPIRED / REPLACE NEW",
          "cyl_next_year": "CYLINDER EXPIRES NEXT YEAR"
        }
      },
      "dashboard": {
        "systems_active": "SYSTEMS ACTIVE",
        "my_queue": "My Queue",
        "team_pending": "Team Pending",
        "completed": "Completed",
        "defect_report": "Defect Report",
        "active_deficiency": "Active Deficiency Records",
        "task_registry": "Personal Task Registry",
        "dispatch_log": "Regional Dispatch Log",
        "registry_empty": "Registry Empty",
        "continue": "Continue",
        "review": "Review",
        "certify": "Certify",
        "dispatch_new": "Dispatch New Job",
        "building_name": "Building Name",
        "select_tech": "Select Field Tech",
        "confirm_dispatch": "Confirm Dispatch"
      },
      "settings": {
        "title": "Settings",
        "subtitle": "System Configuration",
        "security_hub": "Security Hub",
        "identity_details": "Identity Details",
        "app_config": "App Configuration",
        "notifications": "Push Notifications",
        "sync_cloud": "Sync Cloud Data",
        "system_control": "System Control",
        "logout": "Log Out",
        "factory_reset": "Factory Reset",
        "language": "Language / Bahasa",
        "manage_auth": "Manage Authorization",
        "edit_identity": "Edit Identity",
        "update_profile": "Update Profile",
        "sync_status": "Status: {{time}}"
      },
      "bottom_nav": {
        "dashboard": "Dashboard",
        "inspections": "Inspections",
        "scheduler": "Scheduler",
        "settings": "Settings"
      }
    }
  },
  ms: {
    translation: {
      "common": {
        "save": "Simpan",
        "close": "Tutup",
        "back": "Kembali",
        "search": "Cari",
        "loading": "Memuatkan...",
        "status": "Status",
        "online": "Aktif",
        "offline": "Luar Talian",
        "id": "ID",
        "normal": "Normal",
        "faulty": "Kerosakan"
      },
      "login": {
        "access_credentials": "Kredential Akses",
        "email_placeholder": "emel@bestro.com",
        "security_pin": "Pin Keselamatan",
        "forgot_pin": "Lupa?",
        "enter_terminal": "Masuk Terminal",
        "register_new": "Daftar Akaun Baru",
        "failed_alert": "Gagal: Emel atau PIN tidak sah.",
        "identity_verification": "Pengesahan Identiti",
        "reset_pin": "Tetap Semula PIN",
        "staff_id": "ID Staf",
        "verify_identity": "Sahkan Identiti",
        "save_new_pin": "Simpan PIN Baru",
        "pin_changed": "PIN berjaya ditukar."
      },
      "fire_extinguisher": {
        "title": "PEMADAM API",
        "inventory_profile": "Profil Inventori",
        "inventory_summary": "Ringkasan Inventori (Audit)",
        "total_units": "Jumlah Unit",
        "system_desc": "Pemeriksaan berkala unit pemadam api mudah alih bagi memastikan kesediaan operasi dan pematuhan sijil H13 Jabatan Bomba.",
        "desc_placeholder": "Keterangan sistem...",
        "asset_list": "Senarai Aset",
        "add_unit": "Tambah Unit",
        "unit": "UNIT",
        "location_placeholder": "Lokasi Unit...",
        "serial_label": "No. Siri / Label",
        "agent_type": "Jenis Agen",
        "bomba_cert_expiry": "Tarikh Luput Sijil (H13)",
        "mfg_year": "Tahun MFG",
        "cylinder_expiry": "Luput Tabung",
        "weight": "Berat (KG)",
        "pressure_level": "Tahap Tekanan",
        "safety_pin": "Pin Keselamatan",
        "physical_body": "Keadaan Fizikal",
        "final_remarks": "Ulasan Akhir & Gambar Servis",
        "commit_record": "Simpan Rekod Teknikal",
        "remarks_placeholder": "Ringkasan penemuan servis...",
        "defect_placeholder": "Info kerosakan...",
        "status": {
          "no_date": "TIADA TARIKH",
          "expired": "SUDAH LUPUT",
          "renew": "RENEW SEGERA",
          "valid": "SIJIL SAH",
          "cyl_expired": "TABUNG EXPIRED / TUKAR BARU",
          "cyl_next_year": "TABUNG EXPIRED TAHUN DEPAN"
        }
      },
      "dashboard": {
        "systems_active": "SISTEM AKTIF",
        "my_queue": "Giliran Saya",
        "team_pending": "Pasukan Tertunda",
        "completed": "Selesai",
        "defect_report": "Laporan Kecacatan",
        "active_deficiency": "Rekod Kecacatan Aktif",
        "task_registry": "Daftar Tugas Peribadi",
        "dispatch_log": "Log Tugasan Wilayah",
        "registry_empty": "Daftar Kosong",
        "continue": "Teruskan",
        "review": "Semak",
        "certify": "Sahkan",
        "dispatch_new": "Tugasan Baru",
        "building_name": "Nama Bangunan",
        "select_tech": "Pilih Juruteknik",
        "confirm_dispatch": "Sahkan Tugasan"
      },
      "settings": {
        "title": "Tetapan",
        "subtitle": "Konfigurasi Sistem",
        "security_hub": "Hab Keselamatan",
        "identity_details": "Butiran Identiti",
        "app_config": "Konfigurasi Aplikasi",
        "notifications": "Notifikasi Tolak",
        "sync_cloud": "Penyelarasan Data Awan",
        "system_control": "Kawalan Sistem",
        "logout": "Log Keluar",
        "factory_reset": "Tetapan Kilang",
        "language": "Bahasa / Language",
        "manage_auth": "Urus Keizinan",
        "edit_identity": "Edit Identiti",
        "update_profile": "Kemaskini Profil",
        "sync_status": "Status: {{time}}"
      },
      "bottom_nav": {
        "dashboard": "Papan Pemuka",
        "inspections": "Pemeriksaan",
        "scheduler": "Penjadual",
        "settings": "Tetapan"
      }
    }
  }
};

const savedLang = localStorage.getItem('app_language') || 'ms';

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: savedLang,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
