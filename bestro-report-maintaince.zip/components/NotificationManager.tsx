
import React, { useEffect } from 'react';

export const sendLocalNotification = (title: string, body: string, icon?: string) => {
  const isEnabledStr = localStorage.getItem('app_notifications_enabled');
  const isEnabled = isEnabledStr !== null ? JSON.parse(isEnabledStr) : true;
  
  if (!isEnabled) return;

  if (!("Notification" in window)) {
    console.warn("This browser does not support desktop notification");
    return;
  }

  if (Notification.permission === "granted") {
    try {
      const n = new Notification(title, {
        body,
        icon: icon || 'https://cdn-icons-png.flaticon.com/512/564/564619.png',
        badge: 'https://cdn-icons-png.flaticon.com/512/564/564619.png',
        tag: 'bestro-alert' // Prevents duplicate notifications
      });
      
      n.onclick = () => {
        window.focus();
        n.close();
      };
    } catch (e) {
      console.error("Notification error:", e);
    }
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission();
  }
};

const NotificationManager: React.FC = () => {
  useEffect(() => {
    // 1. Initial check and request permission
    if ("Notification" in window) {
      if (Notification.permission === "default") {
        Notification.requestPermission();
      }
    }

    // 2. Maintenance Watchdog Logic
    const runMaintenanceWatchdog = () => {
      const keys = Object.keys(localStorage);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const todayStr = today.toISOString().split('T')[0];
      const notifiedKey = `last_notified_check_${todayStr}`;
      
      // Prevent running multiple times a day if already notified for these specific sites
      const alreadyNotified = JSON.parse(localStorage.getItem('notified_sites_registry') || '{}');

      keys.forEach(key => {
        if (key.startsWith('setup_AUDIT-')) {
          try {
            const data = JSON.parse(localStorage.getItem(key) || '{}');
            if (data.nextServiceDate && data.status !== 'SUBMITTED' && data.status !== 'APPROVED') {
              const dueDate = new Date(data.nextServiceDate);
              dueDate.setHours(0, 0, 0, 0);
              
              const diffTime = dueDate.getTime() - today.getTime();
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
              const siteId = key.replace('setup_', '');

              // Logic: Only notify if we haven't notified for this site today
              if (alreadyNotified[siteId] !== todayStr) {
                if (diffDays === 0) {
                  sendLocalNotification(
                    "DUE TODAY: Maintenance Required",
                    `Scheduled service for ${data.clientName || 'Site'} is due today. Please initiate audit.`
                  );
                  alreadyNotified[siteId] = todayStr;
                } else if (diffDays === 1) {
                  sendLocalNotification(
                    "UPCOMING: Service Reminder",
                    `Reminder: ${data.clientName || 'Site'} is scheduled for service tomorrow.`
                  );
                  alreadyNotified[siteId] = todayStr;
                } else if (diffDays < 0) {
                  sendLocalNotification(
                    "OVERDUE ALERT",
                    `Service for ${data.clientName || 'Site'} is ${Math.abs(diffDays)} days overdue!`
                  );
                  alreadyNotified[siteId] = todayStr;
                }
              }
            }
          } catch (e) {}
        }
      });

      localStorage.setItem('notified_sites_registry', JSON.stringify(alreadyNotified));
    };

    // Run check after a short delay to ensure app is ready
    const timer = setTimeout(runMaintenanceWatchdog, 3000);
    return () => clearTimeout(timer);
  }, []);

  return null;
};

export default NotificationManager;
