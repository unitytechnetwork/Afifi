
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import TopBar from '../components/TopBar';
import { sendLocalNotification } from '../components/NotificationManager';
import { InspectionStatus } from '../types';

interface FaultRecord {
  system: string;
  section: string;
  itemLabel: string;
  description: string;
  photo?: string;
  path: string;
  status: 'Open' | 'Rectified';
}

interface InventoryCount {
  label: string;
  count: number;
}

interface LocationSummary {
  location: string;
  items: InventoryCount[];
}

const Summary: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const auditId = id || 'NEW-AUDIT';
  
  const [sigData, setSigData] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [setupData, setSetupData] = useState<any>(null);

  const DEFECT_TERMS = ['Defective', 'Fault', 'Faulty', 'Damaged', 'Failed', 'Low', 'Broken', 'Leaking', 'Corroded', 'Loose', 'Blocked', 'Blown', 'Expired', 'Missing', 'Abnormal', 'High'];

  const [faultRegistry, setFaultRegistry] = useState<FaultRecord[]>([]);
  const [inventoryRegistry, setInventoryRegistry] = useState<Record<string, LocationSummary[]>>({});
  const [systemStats, setSystemStats] = useState({ totalSystems: 0, totalAssets: 0 });

  const BESTRO_LOGO_DATA_URI = `data:image/svg+xml;base64,${btoa(`
    <svg viewBox="0 0 450 250" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="225" cy="110" rx="200" ry="100" fill="#ec1313" />
      <text x="50%" y="120" text-anchor="middle" fill="white" style="font: bold 75px Arial, sans-serif; letter-spacing: -2px;">BESTRO</text>
      <text x="50%" y="165" text-anchor="middle" fill="white" style="font: 900 24px Arial, sans-serif; letter-spacing: 8px;">ENGINEERING</text>
      <text x="50%" y="235" text-anchor="middle" fill="#333" style="font: italic bold 26px serif;">Connect &amp; Protect</text>
    </svg>
  `)}`;

  useEffect(() => {
    const scanAllSystems = () => {
      const faults: FaultRecord[] = [];
      const inventory: Record<string, LocationSummary[]> = {};
      let totalSystemsCount = 0;
      let totalAssetsCount = 0;
      
      const config = [
        { key: `checklist_${auditId}`, label: 'Main Fire Alarm', path: `/checklist/${auditId}/panel` },
        { key: `gas_suppression_${auditId}`, label: 'Gas Suppression', path: `/checklist/${auditId}/gas` },
        { key: `pump_hosereel_${auditId}`, label: 'Hose Reel Pump', path: `/checklist/${auditId}/pump/hosereel` },
        { key: `pump_wetriser_${auditId}`, label: 'Wet Riser Pump', path: `/checklist/${auditId}/pump/wetriser` },
        { key: `pump_hydrant_${auditId}`, label: 'Hydrant Pump', path: `/checklist/${auditId}/pump/hydrant` },
        { key: `pump_sprinkler_${auditId}`, label: 'Sprinkler Pump', path: `/checklist/${auditId}/pump/sprinkler` },
        { key: `equip_hosereel_${auditId}`, label: 'Hose Reel Assets', path: `/checklist/${auditId}/equip/hosereel` },
        { key: `equip_hydrant_${auditId}`, label: 'Hydrant Assets', path: `/checklist/${auditId}/equip/hydrant` },
        { key: `equip_wetriser_${auditId}`, label: 'Wet Riser Assets', path: `/checklist/${auditId}/equip/wetriser` },
        { key: `equip_dryriser_${auditId}`, label: 'Dry Riser Assets', path: `/checklist/${auditId}/equip/dryriser` },
        { key: `extinguisher_${auditId}`, label: 'Fire Extinguishers', path: `/checklist/${auditId}/extinguisher` },
        { key: `light_emergency_${auditId}`, label: 'Emergency Lighting', path: `/checklist/${auditId}/light/emergency` },
        { key: `light_keluar_${auditId}`, label: 'Keluar Signs', path: `/checklist/${auditId}/light/keluar` },
      ];

      config.forEach(sys => {
        try {
          const raw = localStorage.getItem(sys.key);
          if (!raw) return;
          const data = JSON.parse(raw);
          if (data.isNA) return;

          totalSystemsCount++;

          // 1. SYSTEM SPECIFIC FAULT SCANNING (Ensuring photos are captured)
          if (sys.label === 'Main Fire Alarm') {
            const panels = Array.isArray(data) ? data : [data];
            panels.forEach((p: any) => {
              if (DEFECT_TERMS.includes(p.panelSpecs?.batteryStatus)) {
                faults.push({ system: sys.label, section: p.systemName, itemLabel: 'Battery', description: p.panelSpecs.batteryStatus, photo: p.panelSpecs.batteryPhoto, path: sys.path, status: 'Open' });
              }
              p.cardConditions?.forEach((c: any) => { if (DEFECT_TERMS.includes(c.status)) faults.push({ system: sys.label, section: p.systemName, itemLabel: c.label, description: c.status, photo: c.photo, path: sys.path, status: 'Open' }); });
              p.indicators?.forEach((i: any) => { if (DEFECT_TERMS.includes(i.status)) faults.push({ system: sys.label, section: p.systemName, itemLabel: i.label, description: i.status, photo: i.photo, path: sys.path, status: 'Open' }); });
              p.zones?.forEach((z: any) => { if (DEFECT_TERMS.includes(z.status)) faults.push({ system: sys.label, section: p.systemName, itemLabel: `Zone ${z.zoneNo}`, description: z.status, photo: z.photo, path: sys.path, status: 'Open' }); });
            });
          } else if (sys.label.includes('Pump')) {
            const pumpSets = Array.isArray(data) ? data : [data];
            pumpSets.forEach((u: any) => {
              ['jockeyUnit', 'dutyUnit', 'standbyUnit'].forEach(k => {
                const c = u[k]; if (c && DEFECT_TERMS.includes(c.status)) faults.push({ system: sys.label, section: u.systemName, itemLabel: c.label, description: c.status, photo: c.photo, path: sys.path, status: 'Open' });
              });
              if (DEFECT_TERMS.includes(u.panelLampsStatus)) faults.push({ system: sys.label, section: u.systemName, itemLabel: 'Panel Lamps', description: u.panelLampsStatus, photo: u.panelLampsPhoto, path: sys.path, status: 'Open' });
              if (DEFECT_TERMS.includes(u.panelWiringStatus)) faults.push({ system: sys.label, section: u.systemName, itemLabel: 'Internal Wiring', description: u.panelWiringStatus, photo: u.panelWiringPhoto, path: sys.path, status: 'Open' });
            });
          } else if (sys.label === 'Gas Suppression') {
            const units = Array.isArray(data) ? data : [data];
            units.forEach((u: any) => {
              u.integrationItems?.forEach((i: any) => { if (DEFECT_TERMS.includes(i.status)) faults.push({ system: sys.label, section: u.zoneName, itemLabel: i.label, description: i.status, photo: i.photo, path: sys.path, status: 'Open' }); });
            });
          } else {
            // General Assets (Extinguisher, Equip, Lights)
            const items = Array.isArray(data) ? data : (data.items || []);
            items.forEach((item: any, idx: number) => {
              Object.entries(item).forEach(([k, v]) => {
                if (typeof v === 'string' && DEFECT_TERMS.includes(v)) {
                  const photo = (item.photos && item.photos[k]) || item.photo;
                  faults.push({
                    system: sys.label,
                    section: item.location || 'Building',
                    itemLabel: item.serial || item.brand || `Unit ${idx+1}`,
                    description: `${k.toUpperCase()}: ${v}`,
                    photo: photo,
                    path: sys.path,
                    status: 'Open'
                  });
                }
              });
            });
          }

          // 2. INVENTORY CENSUS LOGIC (Already working well)
          const sysInventory: LocationSummary[] = [];
          if (sys.label === 'Main Fire Alarm') {
            const panels = Array.isArray(data) ? data : [data];
            panels.forEach((p: any) => {
              p.zones?.forEach((z: any) => {
                const zoneDevices = [];
                if (parseInt(z.smokeQty) > 0) zoneDevices.push({ label: 'Smoke Detectors', count: parseInt(z.smokeQty) });
                if (parseInt(z.heatQty) > 0) zoneDevices.push({ label: 'Heat Detectors', count: parseInt(z.heatQty) });
                if (parseInt(z.bellQty) > 0) zoneDevices.push({ label: 'Alarm Bells', count: parseInt(z.bellQty) });
                if (parseInt(z.breakglassQty) > 0) zoneDevices.push({ label: 'Breakglass', count: parseInt(z.breakglassQty) });
                if (zoneDevices.length > 0) { sysInventory.push({ location: `ZONE ${z.zoneNo}: ${z.name}`, items: zoneDevices }); totalAssetsCount += zoneDevices.reduce((sum, d) => sum + d.count, 0); }
              });
            });
          } else {
            const items = Array.isArray(data) ? data : (data.items || []);
            const locMap: Record<string, InventoryCount[]> = {};
            items.forEach((item: any) => {
              const loc = item.location || 'Building Areas';
              if (!locMap[loc]) locMap[loc] = [];
              const label = item.type || item.brand || sys.label;
              const existing = locMap[loc].find(i => i.label === label);
              if (existing) existing.count++; else locMap[loc].push({ label: label, count: 1 });
              totalAssetsCount++;
            });
            Object.entries(locMap).forEach(([loc, counts]) => { sysInventory.push({ location: loc, items: counts }); });
          }
          if (sysInventory.length > 0) inventory[sys.label] = sysInventory;
        } catch (e) {}
      });

      setInventoryRegistry(inventory);
      setFaultRegistry(faults);
      setSystemStats({ totalSystems: totalSystemsCount, totalAssets: totalAssetsCount });

      const savedSetup = localStorage.getItem(`setup_${auditId}`);
      if (savedSetup) setSetupData(JSON.parse(savedSetup));
    };
    scanAllSystems();
  }, [auditId]);

  const handleExport = (exportType: 'pdf' | 'excel') => {
    const site = setupData?.clientName?.toUpperCase() || 'SITE AUDIT';
    const tech = setupData?.techName || 'AUDITOR';
    const techSig = setupData?.techSigData || sigData; 
    const cycleLabel = (setupData?.frequency || 'QUOTATION').toUpperCase();

    // SECTION I: TECHNICAL VERDICT (DYNAMIC CYCLE LABEL)
    let verdictHtml = '';
    if (faultRegistry.length > 0) {
      let faultRows = '';
      faultRegistry.forEach((f, idx) => {
        faultRows += `
          <tr>
            <td align="center" style="vertical-align: middle;">${idx + 1}</td>
            <td style="vertical-align: middle;"><b>${f.system.toUpperCase()}</b><br/><small style="color:#64748b">${f.section}</small></td>
            <td style="vertical-align: middle;">${f.itemLabel}</td>
            <td style="color:#ec1313; font-weight:900; vertical-align: middle;">${f.description}</td>
            <td align="center" style="width: 85px; vertical-align: middle; padding: 5px;">
              ${f.photo ? `<img src="${f.photo}" style="width:75px; height:75px; object-fit:cover; border-radius:4px; border: 0.5pt solid #cbd5e1;" />` : '<span style="color:#cbd5e1; font-size:6pt;">NO EVIDENCE</span>'}
            </td>
          </tr>`;
      });
      verdictHtml = `
        <div style="border: 2pt solid #ec1313; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
          <h3 style="color:#ec1313; margin-top:0; font-size:12pt; border-bottom: 1pt solid #ec1313/20; padding-bottom:5px;">I. DEFECT REGISTRY (${cycleLabel} REFERENCE)</h3>
          <p style="font-size:7pt; color:#475569; margin-bottom:10px;">Authenticated deficiencies detected during site audit. Use for procurement & rectification under ${cycleLabel}.</p>
          <table class="main-table" style="width: 100%; border-collapse: collapse;">
            <tr style="background:#ec1313; color:white; font-weight:900;">
              <td width="30" style="padding:8px; border: 1pt solid #000;">#</td>
              <td width="100" style="padding:8px; border: 1pt solid #000;">SYSTEM</td>
              <td width="130" style="padding:8px; border: 1pt solid #000;">ASSET/LOCATION</td>
              <td style="padding:8px; border: 1pt solid #000;">FINDINGS</td>
              <td width="85" style="padding:8px; border: 1pt solid #000;">EVIDENCE</td>
            </tr>
            ${faultRows}
          </table>
        </div>
      `;
    } else {
      verdictHtml = `
        <div style="border: 2pt solid #059669; padding: 20px; border-radius: 8px; margin-bottom: 20px; text-align:center; background:#f0fdf4;">
          <h3 style="color:#059669; margin-top:0;">I. SYSTEM VERDICT: OPERATIONAL (NORMAL)</h3>
          <p style="color:#065f46; font-weight:bold; font-size:9pt;">All systems verified healthy for ${cycleLabel}. Zero defects found.</p>
        </div>
      `;
    }

    // SECTION II: INVENTORY CENSUS
    let inventoryHtml = '';
    (Object.entries(inventoryRegistry) as [string, LocationSummary[]][]).forEach(([sysLabel, locations]) => {
      let rows = '';
      locations.forEach(loc => {
        loc.items.forEach((item, iIdx) => {
          rows += `<tr>${iIdx === 0 ? `<td rowspan="${loc.items.length}" style="background:#f8fafc; font-weight:900; width:120px; border:1pt solid #cbd5e1;">${loc.location.toUpperCase()}</td>` : ''}<td style="border:1pt solid #cbd5e1;">${item.label.toUpperCase()}</td><td align="center" style="font-weight:900; color:#ec1313; border:1pt solid #cbd5e1;">${item.count}</td></tr>`;
        });
      });
      inventoryHtml += `<table class="main-table" style="width:100%; border-collapse:collapse; margin-bottom:10px;"><tr style="background:#475569; color:white;"><td colspan="3" style="padding:6px; font-weight:900; font-size:8pt; border:1pt solid #000;">${sysLabel.toUpperCase()}</td></tr>${rows}</table>`;
    });

    const fullHtml = `
      <!DOCTYPE html><html><head><meta charset="UTF-8"><style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
        @page { size: A4; margin: 10mm; }
        body { font-family: 'Inter', sans-serif; padding: 15mm; color: #1e293b; background: white; }
        .header { border-bottom: 3pt solid #ec1313; padding-bottom: 15px; margin-bottom: 25px; display:flex; justify-content:space-between; align-items:center; }
        .main-table td { padding: 6px; font-size: 7.5pt; }
      </style></head><body>
        <div class="header"><img src="${BESTRO_LOGO_DATA_URI}" style="width: 140px;" /><div><h1 style="margin:0; color:#ec1313; font-size:16pt;">AUDIT SUMMARY REPORT</h1><p style="margin:0; font-weight:900; font-size:8pt;">SITE: ${site} | ${cycleLabel}</p></div></div>
        ${verdictHtml}
        <h2 style="font-size:12pt; border-bottom:1pt solid #000; padding-bottom:5px; margin-top:30px;">II. INVENTORY CENSUS</h2>
        ${inventoryHtml}
        <div style="margin-top:50px; display:flex; justify-content:space-between;"><div style="width:200px;"><p style="font-size:8pt; font-weight:900;">AUDITOR SIGNATURE</p><div style="border:1pt solid #cbd5e1; height:70px; display:flex; align-items:center; justify-content:center;">${techSig ? `<img src="${techSig}" style="max-height:60px;"/>` : ''}</div><p style="font-size:9pt; font-weight:900;">${tech}</p></div></div>
      </body></html>
    `;

    if (exportType === 'excel') {
      const blob = new Blob([fullHtml], { type: 'application/vnd.ms-excel' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a"); link.href = url; link.setAttribute("download", `BESTRO_SUMMARY_${auditId}.xls`); link.click();
    } else {
      const pWin = window.open('', '_blank'); if (pWin) { pWin.document.write(fullHtml); pWin.document.close(); }
    }
  };

  const handleFinalize = () => {
    if (!sigData) return;
    const savedSetup = localStorage.getItem(`setup_${auditId}`);
    if (savedSetup) {
      const data = JSON.parse(savedSetup);
      data.status = InspectionStatus.SUBMITTED;
      data.techSigData = sigData; 
      localStorage.setItem(`setup_${auditId}`, JSON.stringify(data));
    }
    setIsSubmitting(true);
    setTimeout(() => navigate('/success', { state: { auditId } }), 1500);
  };

  return (
    <div className="flex flex-col h-full bg-background-dark overflow-y-auto no-scrollbar pb-32">
      <TopBar title="Certification Hub" subtitle={`AUDIT #${auditId}`} showBack />
      
      {isSubmitting ? (
        <div className="flex-1 flex flex-col items-center justify-center p-10 bg-[#181111] fixed inset-0 z-[100]"><div className="w-20 h-20 border-4 border-primary/20 border-t-primary rounded-full animate-spin mb-8" /><h2 className="text-xl font-black italic uppercase tracking-widest text-white">Finalizing Dossier...</h2></div>
      ) : (
        <div className="p-4 flex flex-col gap-6">
          
          {/* Header Card */}
          <div className="bg-surface-dark p-6 rounded-3xl border-l-8 border-primary shadow-2xl">
             <div className="flex justify-between items-start">
                <div>
                   <p className="text-[9px] font-black text-text-muted uppercase tracking-widest">Site Audit Summary</p>
                   <h1 className="text-2xl font-black italic uppercase text-white leading-tight">{setupData?.clientName || 'SITE AUDIT'}</h1>
                   <div className="bg-primary/10 border border-primary/20 px-2 py-0.5 rounded mt-2 inline-block"><span className="text-[8px] font-black text-primary uppercase tracking-widest">{setupData?.frequency || 'Audit Cycle'}</span></div>
                </div>
                <button onClick={() => handleExport('pdf')} className="w-11 h-11 bg-primary rounded-xl flex items-center justify-center text-white shadow-lg active:scale-95 transition-all"><span className="material-symbols-outlined">picture_as_pdf</span></button>
             </div>
             <div className="flex gap-6 mt-5">
                <div className="flex flex-col"><span className="text-[8px] font-black text-text-muted uppercase tracking-widest">Assets</span><span className="text-2xl font-black text-emerald-500">{systemStats.totalAssets}</span></div>
                <div className="flex flex-col"><span className="text-[8px] font-black text-text-muted uppercase tracking-widest">Defects</span><span className={`text-2xl font-black ${faultRegistry.length > 0 ? 'text-primary' : 'text-emerald-500'}`}>{faultRegistry.length}</span></div>
             </div>
          </div>

          {/* SECTION 1: TECHNICAL VERDICT (SHOWING CYCLE) */}
          <div className={`p-6 rounded-[2.5rem] border shadow-2xl ${faultRegistry.length > 0 ? 'bg-primary/5 border-primary/30' : 'bg-emerald-500/5 border-emerald-500/30'}`}>
             <div className="flex items-center gap-3 mb-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg ${faultRegistry.length > 0 ? 'bg-primary' : 'bg-emerald-500'}`}>
                   <span className="material-symbols-outlined text-2xl">{faultRegistry.length > 0 ? 'report' : 'verified'}</span>
                </div>
                <div className="flex flex-col">
                   <h3 className="text-sm font-black uppercase tracking-widest text-white italic">Technical Verdict</h3>
                   <p className={`text-[9px] font-black uppercase ${faultRegistry.length > 0 ? 'text-primary' : 'text-emerald-500'}`}>
                      {setupData?.frequency ? `${setupData.frequency}: ` : ''}{faultRegistry.length > 0 ? 'Rectification Required' : 'Operational (Normal)'}
                   </p>
                </div>
             </div>
             {faultRegistry.length > 0 ? (
                <div className="flex flex-col gap-3">
                   <p className="text-[10px] text-text-muted font-bold italic">Senarai kerosakan dikesan bersama bukti gambar:</p>
                   <div className="flex flex-col gap-3">
                      {faultRegistry.map((f, i) => (
                        <div key={i} className="bg-background-dark/50 p-3 rounded-2xl border border-white/5 flex items-center gap-4 group">
                           <div className="w-14 h-14 rounded-xl bg-background-dark overflow-hidden border border-white/10 shrink-0 flex items-center justify-center shadow-inner">
                              {f.photo ? (
                                <img src={f.photo} className="w-full h-full object-cover" alt="Defect" />
                              ) : (
                                <span className="material-symbols-outlined text-white/10 text-xl">image_not_supported</span>
                              )}
                           </div>
                           <div className="flex-1 min-w-0">
                              <div className="flex flex-col">
                                 <span className="text-[8px] font-black text-primary uppercase">{f.system}</span>
                                 <h4 className="text-[10px] font-bold text-white truncate leading-tight">{f.itemLabel}</h4>
                                 <span className="text-[8px] text-text-muted truncate mt-1 italic">Defect: {f.description}</span>
                              </div>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
             ) : (
                <p className="text-[10px] text-text-muted font-bold italic leading-relaxed">Semua sistem dalam keadaan normal bagi rujukan {setupData?.frequency || 'Audit'}. Tiada kerosakan dikesan.</p>
             )}
          </div>

          {/* SECTION 2: INVENTORY CENSUS */}
          <div className="flex flex-col gap-4">
            <h3 className="text-[10px] font-black text-text-muted uppercase tracking-[0.3em] italic px-2">Inventory Audit Census</h3>
            <div className="flex flex-col gap-4">
              {(Object.entries(inventoryRegistry) as [string, LocationSummary[]][]).map(([sysLabel, locations]) => (
                <div key={sysLabel} className="bg-surface-dark rounded-3xl border border-white/5 overflow-hidden shadow-xl">
                   <div className="bg-white/5 px-5 py-3 border-b border-white/5 flex items-center justify-between"><span className="text-[10px] font-black uppercase tracking-widest text-emerald-500 italic">{sysLabel}</span></div>
                   <div className="p-3 flex flex-col gap-3">
                      {locations.map((loc, lIdx) => (
                        <div key={lIdx} className="bg-background-dark/40 rounded-2xl p-4 border border-white/5">
                           <div className="flex items-center gap-2 mb-3"><span className="material-symbols-outlined text-sm text-text-muted">location_on</span><span className="text-[10px] font-black uppercase text-white tracking-tight">{loc.location}</span></div>
                           <div className="grid grid-cols-1 gap-2">
                             {loc.items.map((item, iIdx) => (
                               <div key={iIdx} className="bg-white/5 p-2.5 rounded-xl flex items-center justify-between border border-white/5">
                                 <span className="text-[10px] font-bold text-text-muted uppercase truncate mr-2">{item.label}</span>
                                 <span className="text-[12px] font-black text-white bg-primary/20 px-3 py-0.5 rounded">{item.count}</span>
                               </div>
                             ))}
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certification Pad */}
          <div className="bg-surface-dark p-6 rounded-3xl border border-white/5 flex flex-col gap-6 shadow-2xl mb-20">
             <div className="flex items-center gap-2"><span className="material-symbols-outlined text-primary text-sm">verified_user</span><h3 className="font-black uppercase tracking-[0.2em] text-[10px] italic">Auditor Certification</h3></div>
             <p className="text-[9px] text-text-muted font-medium -mt-4 leading-relaxed italic">"I certify that the findings in this technical registry for {setupData?.frequency || 'Audit Cycle'} are accurate based on the site inspection conduct."</p>
             <SignaturePad onSign={setSigData} placeholder="Lead Auditor Digital Signature" />
          </div>
        </div>
      )}

      {!isSubmitting && (
        <div className="fixed bottom-0 w-full max-w-md bg-background-dark/95 backdrop-blur-xl border-t border-white/5 p-5 pb-10 z-50">
           <button 
             onClick={handleFinalize} 
             disabled={!sigData} 
             className={`w-full h-16 rounded-2xl font-black uppercase tracking-[0.2em] text-sm flex items-center justify-center gap-3 shadow-2xl ${sigData ? 'bg-primary text-white shadow-primary/30' : 'bg-white/5 text-white/20'}`}
           >
             <span>Lock & Commit Report</span>
             <span className="material-symbols-outlined">verified</span>
           </button>
        </div>
      )}
    </div>
  );
};

const SignaturePad: React.FC<{ onSign: (data: string) => void; placeholder: string }> = ({ onSign, placeholder }) => {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = React.useState(false);
  const [isEmpty, setIsEmpty] = React.useState(true);
  const startDrawing = (e: any) => { setIsDrawing(true); draw(e); };
  const stopDrawing = () => { setIsDrawing(false); if (canvasRef.current) onSign(canvasRef.current.toDataURL()); };
  const draw = (e: any) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
    ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.strokeStyle = '#ec1313';
    if (isEmpty) { ctx.beginPath(); ctx.moveTo(x, y); setIsEmpty(false); } else { ctx.lineTo(x, y); ctx.stroke(); }
  };
  return (
    <div className="relative w-full h-36 bg-background-dark/80 rounded-2xl border border-white/10 overflow-hidden cursor-crosshair shadow-inner">
      {isEmpty && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none opacity-20 text-center px-4">
          <span className="material-symbols-outlined text-4xl animate-pulse">edit_square</span>
          <span className="text-[8px] font-black uppercase tracking-[0.2em] mt-2 leading-relaxed">{placeholder}</span>
        </div>
      )}
      <canvas ref={canvasRef} width={400} height={144} onMouseDown={startDrawing} onMouseMove={draw} onMouseUp={stopDrawing} onMouseLeave={stopDrawing} onTouchStart={startDrawing} onTouchMove={draw} onTouchEnd={stopDrawing} className="w-full h-full touch-none" />
      {!isEmpty && <button onClick={() => { const c = canvasRef.current; c?.getContext('2d')?.clearRect(0,0,c.width,c.height); setIsEmpty(true); onSign(''); }} className="absolute top-2 right-2 p-2 bg-white/5 rounded-xl text-[7px] font-black uppercase text-text-muted">Clear</button>}
    </div>
  );
};

export default Summary;
