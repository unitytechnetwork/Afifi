
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { GoogleGenAI } from "@google/genai";
import TopBar from '../components/TopBar';

// Helper: Compress Image to prevent localStorage overflow
const compressImage = (base64Str: string, maxWidth = 1024, quality = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
  });
};

interface Extinguisher {
  id: string;
  serial: string;
  type: string;
  weight: string;
  location: string;
  mfgYear: string;
  replacementYear: string; 
  pressure: 'Normal' | 'Low';
  pin: 'Intact' | 'Broken';
  cableTie: 'Intact' | 'Broken';
  bombaCert: 'Valid' | 'Expired';
  bombaCertExpiry: string; 
  physicalBody: 'Good' | 'Damaged';
  photos: Record<string, string>;
  remarks: Record<string, string>;
}

const FireExtinguisher: React.FC = () => {
  const { t } = useTranslation();
  const { id } = useParams();
  const navigate = useNavigate();
  const auditId = id || 'NEW-AUDIT';
  const scanInputRef = useRef<HTMLInputElement>(null);
  const [scanningId, setScanningId] = useState<string | null>(null);
  const [isAiProcessing, setIsAiProcessing] = useState(false);

  const [systemDescription, setSystemDescription] = useState(t('fire_extinguisher.system_desc'));
  const [systemOverallStatus, setSystemOverallStatus] = useState<'Normal' | 'Faulty' | 'Partial' | 'N/A'>('Normal');
  const [overallRemarks, setOverallRemarks] = useState('');
  const [servicePhotos, setServicePhotos] = useState<string[]>(['', '', '', '']);

  const getDefaultItem = (): Extinguisher => ({ 
    id: Date.now().toString() + Math.random(), 
    serial: '', type: 'ABC Powder', weight: '9kg', location: '', 
    mfgYear: new Date().getFullYear().toString(), 
    replacementYear: (new Date().getFullYear() + 10).toString(),
    pressure: 'Normal', pin: 'Intact', cableTie: 'Intact',
    bombaCert: 'Valid', bombaCertExpiry: '', physicalBody: 'Good', remarks: {}, photos: {}
  });

  const [items, setItems] = useState<Extinguisher[]>([]);

  // NEW: Memoized Summary for Audit
  const inventorySummary = useMemo(() => {
    const summary: Record<string, number> = {};
    items.forEach(item => {
      const type = item.type || 'Unknown';
      summary[type] = (summary[type] || 0) + 1;
    });
    return summary;
  }, [items]);

  useEffect(() => {
    const saved = localStorage.getItem(`extinguisher_${auditId}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setItems((parsed.items || []).map((i: any) => ({ ...getDefaultItem(), ...i })));
        if (parsed.systemOverallStatus) setSystemOverallStatus(parsed.systemOverallStatus);
        if (parsed.overallRemarks) setOverallRemarks(parsed.overallRemarks);
        if (parsed.servicePhotos) setServicePhotos(parsed.servicePhotos);
        if (parsed.systemDescription) setSystemDescription(parsed.systemDescription);
      } catch (e) { console.error(e); }
    } else {
      setItems([getDefaultItem()]);
    }
  }, [auditId]);

  useEffect(() => {
    if (items.length > 0) {
      localStorage.setItem(`extinguisher_${auditId}`, JSON.stringify({ 
        items, systemOverallStatus, overallRemarks, servicePhotos, systemDescription 
      }));
    }
  }, [items, systemOverallStatus, overallRemarks, servicePhotos, systemDescription, auditId]);

  const updateItem = (itemId: string, updates: Partial<Extinguisher>) => {
    setItems(items.map(i => i.id === itemId ? { ...i, ...updates } : i));
  };

  const handleMfgYearChange = (itemId: string, yearStr: string) => {
    const year = parseInt(yearStr);
    if (!isNaN(year)) {
      updateItem(itemId, { 
        mfgYear: yearStr,
        replacementYear: (year + 10).toString()
      });
    } else {
      updateItem(itemId, { mfgYear: yearStr });
    }
  };

  const getExpiryStatus = (expiryDate: string) => {
    if (!expiryDate) return { label: t('fire_extinguisher.status.no_date'), color: 'text-text-muted', bg: 'bg-white/5' };
    
    const today = new Date();
    const exp = new Date(expiryDate);
    const diffTime = exp.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { label: t('fire_extinguisher.status.expired'), color: 'text-white', bg: 'bg-primary animate-pulse' };
    } else if (diffDays <= 30) {
      return { label: `${t('fire_extinguisher.status.renew')} (${diffDays} ${t('dashboard.days', { defaultValue: 'DAYS' })})`, color: 'text-white', bg: 'bg-amber-600 shadow-lg shadow-amber-600/20' };
    } else {
      return { label: t('fire_extinguisher.status.valid'), color: 'text-emerald-500', bg: 'bg-emerald-500/10' };
    }
  };

  const getCylinderStatus = (replaceYear: string) => {
    const currentYear = new Date().getFullYear();
    const rYear = parseInt(replaceYear);
    if (isNaN(rYear)) return null;

    if (rYear <= currentYear) {
      return { label: t('fire_extinguisher.status.cyl_expired'), color: 'text-white', bg: 'bg-primary shadow-lg shadow-primary/20' };
    } else if (rYear - currentYear <= 1) {
      return { label: t('fire_extinguisher.status.cyl_next_year'), color: 'text-amber-500', bg: 'bg-amber-500/10' };
    }
    return null;
  };

  const processScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !scanningId) return;
    setIsAiProcessing(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: { parts: [{ inlineData: { data: base64Data, mimeType: file.type } }, { text: "Return only the serial number. If it's a bomba label, return the label number." }] }
        });
        const result = response.text?.trim() || '';
        if (result) updateItem(scanningId, { serial: result });
        setIsAiProcessing(false);
      };
      reader.readAsDataURL(file);
    } catch (err) { setIsAiProcessing(false); }
  };

  return (
    <div className="flex flex-col h-full bg-background-dark overflow-y-auto no-scrollbar pb-32">
      <TopBar title={t('fire_extinguisher.title')} subtitle={`REF: ${auditId}`} showBack />
      
      {isAiProcessing && (
        <div className="fixed inset-0 z-[100] bg-black/80 flex flex-col items-center justify-center p-10 text-center animate-in fade-in">
          <div className="w-16 h-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin mb-4" />
          <p className="text-xs font-black uppercase text-white tracking-widest italic">AI SCANNING SYSTEM...</p>
        </div>
      )}
      
      <input type="file" ref={scanInputRef} className="hidden" accept="image/*" onChange={processScan} />

      <div className="p-4 flex flex-col gap-6 animate-in fade-in duration-500">
        
        {/* NEW Section: Inventory Summary (Audit View) */}
        <section className="bg-surface-dark border border-white/5 p-6 rounded-[2rem] shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full -mr-16 -mt-16 blur-2xl" />
           <div className="flex items-center gap-2 mb-4 relative z-10">
              <span className="material-symbols-outlined text-emerald-500 text-sm">inventory</span>
              <h3 className="text-[10px] font-black uppercase text-emerald-500 tracking-widest italic">{t('fire_extinguisher.inventory_summary')}</h3>
           </div>
           
           <div className="grid grid-cols-2 gap-4 relative z-10">
              <div className="bg-background-dark/50 p-4 rounded-2xl border border-white/5 flex flex-col items-center justify-center gap-1">
                 <span className="text-2xl font-black text-white">{items.length}</span>
                 <span className="text-[8px] font-black text-text-muted uppercase tracking-tighter">{t('fire_extinguisher.total_units')}</span>
              </div>
              <div className="flex flex-col gap-2">
                 {Object.entries(inventorySummary).map(([type, count]) => (
                   <div key={type} className="flex justify-between items-center bg-white/5 px-3 py-1.5 rounded-lg border border-white/5">
                      <span className="text-[9px] font-bold text-text-muted uppercase">{type}</span>
                      <span className="text-[11px] font-black text-emerald-500">{count}</span>
                   </div>
                 ))}
                 {items.length === 0 && <span className="text-[9px] text-text-muted italic opacity-30">Tiada data inventori...</span>}
              </div>
           </div>
        </section>

        <section className="bg-primary/10 border border-primary/20 p-5 rounded-2xl flex flex-col gap-4 shadow-xl">
           <div className="flex justify-between items-center border-b border-primary/20 pb-3">
              <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">{t('fire_extinguisher.inventory_profile')}</h3>
              <select value={systemOverallStatus} onChange={(e) => setSystemOverallStatus(e.target.value as any)} className="bg-background-dark/50 border border-primary/40 rounded px-2 h-6 text-[8px] font-black uppercase text-white">
                <option value="Normal">{t('common.normal')}</option><option value="Faulty">{t('common.faulty')}</option>
              </select>
           </div>
           <textarea value={systemDescription} onChange={(e) => setSystemDescription(e.target.value)} className="bg-background-dark/50 border-white/5 border rounded-xl p-3 text-[10px] font-medium text-white h-16 outline-none focus:ring-1 focus:ring-primary" placeholder={t('fire_extinguisher.desc_placeholder')} />
        </section>

        <div className="flex justify-between items-center px-1">
           <h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">{t('fire_extinguisher.asset_list')} ({items.length})</h3>
           <button onClick={() => setItems([...items, getDefaultItem()])} className="text-[9px] font-black text-primary bg-primary/10 px-4 py-2 rounded-xl border border-primary/20 transition-all active:scale-95">
              + {t('fire_extinguisher.add_unit')}
           </button>
        </div>

        <div className="flex flex-col gap-6">
          {items.map((item, idx) => {
            const expStatus = getExpiryStatus(item.bombaCertExpiry);
            const cylinderStatus = getCylinderStatus(item.replacementYear);
            return (
              <div key={item.id} className="p-6 rounded-[2.5rem] bg-surface-dark border border-white/5 shadow-2xl relative group overflow-hidden animate-in slide-in-from-bottom">
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-primary/20" />
                  <button onClick={() => setItems(items.filter(i => i.id !== item.id))} className="absolute top-6 right-6 text-text-muted hover:text-primary transition-all"><span className="material-symbols-outlined text-sm">delete</span></button>
                  
                  <div className="flex items-center gap-2 border-b border-white/5 pb-4 mb-5">
                    <span className="text-[11px] font-black italic uppercase text-primary">{t('fire_extinguisher.unit')} #{idx + 1}</span>
                    <input type="text" value={item.location} onChange={(e) => updateItem(item.id, { location: e.target.value })} className="flex-1 bg-transparent border-none text-[11px] font-bold text-white focus:ring-0 placeholder:text-white/10" placeholder={t('fire_extinguisher.location_placeholder')} />
                  </div>

                  <div className="flex flex-col gap-5">
                    <div className="grid grid-cols-2 gap-3">
                        <div className="relative">
                          <label className="text-[7px] font-black text-text-muted uppercase ml-1">{t('fire_extinguisher.serial_label')}</label>
                          <div className="flex items-center">
                            <input type="text" value={item.serial} onChange={(e) => updateItem(item.id, { serial: e.target.value })} className="w-full bg-background-dark/50 border-none rounded-xl h-10 pl-3 pr-9 text-[10px] font-bold text-white" placeholder="SN-XXXX" />
                            <button onClick={() => { setScanningId(item.id); scanInputRef.current?.click(); }} className="absolute right-1 w-8 h-8 text-primary"><span className="material-symbols-outlined text-sm">barcode_scanner</span></button>
                          </div>
                        </div>
                        <div>
                          <label className="text-[7px] font-black text-text-muted uppercase ml-1">{t('fire_extinguisher.agent_type')}</label>
                          <select value={item.type} onChange={(e) => updateItem(item.id, { type: e.target.value })} className="w-full bg-background-dark/50 border-none rounded-xl h-10 px-3 text-[10px] font-bold text-primary appearance-none">
                            <option>ABC Powder</option><option>CO2 Gas</option><option>Water Mist</option><option>Foam</option>
                          </select>
                        </div>
                    </div>

                    <div className="bg-background-dark/40 p-4 rounded-2xl border border-white/5">
                        <div className="flex justify-between items-center mb-3">
                          <label className="text-[8px] font-black text-primary uppercase tracking-widest italic">{t('fire_extinguisher.bomba_cert_expiry')}</label>
                          <div className={`px-2 py-0.5 rounded text-[6px] font-black uppercase tracking-tighter ${expStatus.bg} ${expStatus.color} transition-all`}>
                            {expStatus.label}
                          </div>
                        </div>
                        <input 
                          type="date" 
                          value={item.bombaCertExpiry} 
                          onChange={(e) => updateItem(item.id, { bombaCertExpiry: e.target.value })} 
                          className={`w-full bg-background-dark border-none rounded-xl h-12 px-4 text-xs font-black transition-all ${expStatus.label.includes('RENEW') || expStatus.label.includes('LUPUT') || expStatus.label.includes('EXPIRED') ? 'text-amber-500 ring-1 ring-amber-500/30' : 'text-emerald-500'}`} 
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <div className="flex flex-col gap-1">
                          <div className="flex justify-between items-center px-1">
                            <label className="text-[7px] font-black text-text-muted uppercase">{t('fire_extinguisher.mfg_year')}</label>
                            <span className="text-[6px] font-black text-primary uppercase">Auto-Calc</span>
                          </div>
                          <input type="number" value={item.mfgYear} onChange={(e) => handleMfgYearChange(item.id, e.target.value)} className="w-full bg-background-dark/50 border-none rounded-xl h-10 px-3 text-[10px] font-bold text-white outline-none" placeholder="2024" />
                        </div>
                        <div className="flex flex-col gap-1">
                          <div className="flex justify-between items-center px-1">
                            <label className="text-[7px] font-black text-primary uppercase">{t('fire_extinguisher.cylinder_expiry')}</label>
                            <span className="text-[6px] font-black text-emerald-500 uppercase">10 YRS</span>
                          </div>
                          <div className="relative">
                            <input type="number" value={item.replacementYear} onChange={(e) => updateItem(item.id, { replacementYear: e.target.value })} className={`w-full bg-background-dark/50 border-none rounded-xl h-10 px-3 text-[10px] font-black outline-none ${cylinderStatus ? 'text-primary ring-1 ring-primary/30' : 'text-emerald-500'}`} />
                            {cylinderStatus && (
                              <div className="absolute -top-1 -right-1">
                                <span className="flex h-2 w-2">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                    </div>

                    {cylinderStatus && (
                       <div className={`p-3 rounded-xl border border-primary/20 flex items-center gap-3 animate-in slide-in-from-top ${cylinderStatus.bg}`}>
                          <span className="material-symbols-outlined text-sm text-white">warning</span>
                          <span className="text-[8px] font-black uppercase text-white tracking-widest">{cylinderStatus.label}</span>
                       </div>
                    )}

                    <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[7px] font-black text-text-muted uppercase ml-1">{t('fire_extinguisher.weight')}</label>
                          <input type="text" value={item.weight} onChange={(e) => updateItem(item.id, { weight: e.target.value })} className="w-full bg-background-dark/50 border-none rounded-xl h-10 px-3 text-[10px] font-bold text-white" placeholder="9kg" />
                        </div>
                        <div className="flex items-end">
                          <div className="w-full p-2 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-center">
                              <span className="text-[8px] font-black text-primary uppercase text-center tracking-tighter italic">Cylinder Life Cycle</span>
                          </div>
                        </div>
                    </div>

                    <div className="space-y-4 pt-2">
                        <StatusRow label={t('fire_extinguisher.pressure_level')} value={item.pressure} options={['Normal', 'Low']} onToggle={(v:any) => updateItem(item.id, { pressure: v })} 
                          remark={item.remarks.pressure} photo={item.photos.pressure} onRemark={(t:string) => updateItem(item.id, { remarks: {...item.remarks, pressure: t} })}
                          onPhoto={async (p:string) => { const cp = await compressImage(p); updateItem(item.id, { photos: {...item.photos, pressure: cp} }); }}
                        />
                        <StatusRow label={t('fire_extinguisher.safety_pin')} value={item.pin} options={['Intact', 'Broken']} onToggle={(v:any) => updateItem(item.id, { pin: v })} 
                          remark={item.remarks.pin} photo={item.photos.pin} onRemark={(t:string) => updateItem(item.id, { remarks: {...item.remarks, pin: t} })}
                          onPhoto={async (p:string) => { const cp = await compressImage(p); updateItem(item.id, { photos: {...item.photos, pin: cp} }); }}
                        />
                        <StatusRow label={t('fire_extinguisher.physical_body')} value={item.physicalBody} options={['Good', 'Damaged']} onToggle={(v:any) => updateItem(item.id, { physicalBody: v })} 
                          remark={item.remarks.physicalBody} photo={item.photos.physicalBody} onRemark={(t:string) => updateItem(item.id, { remarks: {...item.remarks, physicalBody: t} })}
                          onPhoto={async (p:string) => { const cp = await compressImage(p); updateItem(item.id, { photos: {...item.photos, physicalBody: cp} }); }}
                        />
                    </div>
                  </div>
              </div>
            );
          })}
        </div>

        <section className="bg-surface-dark p-6 rounded-[2.5rem] border border-white/5 shadow-xl mt-4">
           <div className="flex items-center gap-2 mb-5 border-b border-white/5 pb-4">
              <span className="material-symbols-outlined text-primary text-sm">history_edu</span>
              <h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">{t('fire_extinguisher.final_remarks')}</h3>
           </div>
           <textarea value={overallRemarks} onChange={(e) => setOverallRemarks(e.target.value)} className="w-full bg-background-dark/40 border-none rounded-2xl p-4 text-[11px] h-24 mb-6 text-white focus:ring-1 focus:ring-primary outline-none" placeholder={t('fire_extinguisher.remarks_placeholder')} />
           <div className="grid grid-cols-4 gap-3">
              {servicePhotos.map((photo, idx) => (
                <PhotoCaptureBox key={idx} photo={photo} onCapture={async (p) => {
                  const cp = await compressImage(p);
                  const n = [...servicePhotos]; n[idx] = cp; setServicePhotos(n);
                }} />
              ))}
           </div>
        </section>
      </div>

      <div className="fixed bottom-0 w-full max-w-md bg-background-dark/95 border-t border-white/5 p-6 pb-12 z-50 shadow-2xl">
         <button onClick={() => navigate(`/checklist/${auditId}`)} className="w-full h-14 bg-primary text-white font-black uppercase tracking-widest text-xs rounded-xl flex items-center justify-center gap-3 active:scale-[0.98] transition-all">
            <span>{t('fire_extinguisher.commit_record')}</span>
            <span className="material-symbols-outlined text-sm">verified_user</span>
         </button>
      </div>
    </div>
  );
};

const StatusRow: React.FC<any> = ({ label, value, options, onToggle, remark, photo, onRemark, onPhoto }) => {
  const { t } = useTranslation();
  const isOk = ['Normal', 'Intact', 'Valid', 'Good'].includes(value);
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-black uppercase text-white tracking-widest italic">{label}</span>
        <div className="flex gap-1.5">
          {options.map((o: string) => {
             const isPositive = ['Normal', 'Intact', 'Valid', 'Good'].includes(o);
             const isSelected = value === o;
             return (
               <button key={o} onClick={() => onToggle(o)} className={`px-4 h-8 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${isSelected ? (isPositive ? 'bg-emerald-600 text-white shadow-lg' : 'bg-primary text-white shadow-lg') : 'bg-background-dark/50 text-text-muted opacity-40'}`}>{o}</button>
             );
          })}
        </div>
      </div>
      {!isOk && (
        <div className="bg-background-dark/40 rounded-2xl p-3 flex gap-3 animate-in slide-in-from-top duration-300">
           <PhotoCaptureBox photo={photo} onCapture={onPhoto} className="w-16 h-16 shrink-0" />
           <textarea value={remark || ''} onChange={(e) => onRemark(e.target.value)} className="flex-1 bg-transparent border-none text-[10px] h-16 p-0 text-white italic placeholder:text-white/10 focus:ring-0" placeholder={t('fire_extinguisher.defect_placeholder')} />
        </div>
      )}
    </div>
  );
};

const PhotoCaptureBox: React.FC<{ photo?: string; onCapture: (p: string) => void; className?: string }> = ({ photo, onCapture, className }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onCapture(reader.result as string);
      reader.readAsDataURL(file);
    }
  };
  return (
    <div onClick={() => fileRef.current?.click()} className={`bg-background-dark rounded-xl border border-primary/20 flex items-center justify-center overflow-hidden cursor-pointer relative group transition-all hover:border-primary/50 shadow-inner ${className || 'w-full aspect-square'}`}>
      {photo ? <img src={photo} className="w-full h-full object-cover" /> : <span className="material-symbols-outlined text-primary text-xl">camera_outdoor</span>}
      <input type="file" ref={fileRef} className="hidden" accept="image/*" onChange={handleFile} />
    </div>
  );
};

export default FireExtinguisher;
