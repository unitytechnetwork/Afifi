
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TopBar from '../components/TopBar';

// Helper: Compress Image
const compressImage = (base64Str: string, maxWidth = 1024, quality = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
  });
};

interface PumpComponent {
  label: string;
  type: 'Electric' | 'Diesel';
  mode: 'Auto' | 'Manual' | 'Off';
  status: 'Normal' | 'Fault';
  loadValue: string;
  cutIn: string;
  cutOut: string;
  batteryVolt?: string;
  chargerVolt?: string;
  photo?: string;
  remarks?: string;
}

interface PumpData {
  id: string;
  systemName: string;
  location: string;
  systemDescription: string;
  systemOverallStatus: 'Normal' | 'Faulty' | 'Partial' | 'N/A';
  headerPressure: string;
  tankLevel: string;
  jockeyUnit?: PumpComponent;
  dutyUnit: PumpComponent;
  standbyUnit: PumpComponent;
  jockeyRating: string;
  motorRating: string;
  engineRating: string;
  pumpVibration: 'Normal' | 'High';
  pumpNoise: 'Normal' | 'Abnormal';
  glandPacking: 'Normal' | 'Leaking';
  pumpCondition: 'Normal' | 'Fault';
  valveCondition: 'Normal' | 'Fault';
  panelIncomingVolt: string;
  panelLampsStatus: 'Normal' | 'Fault';
  panelLampsPhoto?: string;
  panelLampsRemarks?: string;
  panelWiringStatus: 'Normal' | 'Fault';
  panelWiringPhoto?: string;
  panelWiringRemarks?: string;
  selectorSwitchStatus: 'Normal' | 'Fault';
  selectorSwitchPhoto?: string;
  selectorSwitchRemarks?: string;
  overallRemarks: string;
  servicePhotos: string[];
}

const PumpSystem: React.FC = () => {
  const { id, type } = useParams();
  const navigate = useNavigate();
  const auditId = id || 'NEW-AUDIT';
  const pumpType = type || 'hosereel';
  const isHoseReel = pumpType.toLowerCase().includes('hosereel');

  // State untuk modal padam
  const [deleteTarget, setDeleteTarget] = useState<PumpData | null>(null);

  const getBaseDefaults = (index: number): PumpData => ({
    id: Date.now().toString() + index,
    systemName: index === 0 ? 'Main Pump Set' : `Pump Set ${index + 1}`,
    location: 'Pump Room Ground Floor',
    systemDescription: `Routine maintenance for ${pumpType.toUpperCase()} pump system.`,
    systemOverallStatus: 'Normal',
    headerPressure: '7.0',
    tankLevel: 'Full',
    dutyUnit: { label: 'Duty Pump', type: 'Electric', mode: 'Auto', status: 'Normal', loadValue: '15.5', cutIn: '6.0', cutOut: '8.0', remarks: '' },
    standbyUnit: { label: 'Standby Pump', type: 'Diesel', mode: 'Auto', status: 'Normal', loadValue: '100', cutIn: '5.5', cutOut: '8.0', batteryVolt: '12.6', chargerVolt: '13.8', remarks: '' },
    jockeyRating: '1.5HP', motorRating: '15HP', engineRating: '25HP',
    pumpVibration: 'Normal', pumpNoise: 'Normal', glandPacking: 'Normal', pumpCondition: 'Normal', valveCondition: 'Normal',
    panelIncomingVolt: '415', panelLampsStatus: 'Normal', panelWiringStatus: 'Normal', selectorSwitchStatus: 'Normal',
    overallRemarks: '',
    servicePhotos: ['', '', '', '']
  });

  const [systems, setSystems] = useState<PumpData[]>(() => {
    const saved = localStorage.getItem(`pump_${pumpType}_${auditId}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return Array.isArray(parsed) ? parsed : [parsed];
      } catch (e) { console.error(e); }
    }
    const initial = getBaseDefaults(0);
    if (!isHoseReel) initial.jockeyUnit = { label: 'Jockey Pump', type: 'Electric', mode: 'Auto', status: 'Normal', loadValue: '1.2', cutIn: '7.5', cutOut: '8.5', remarks: '' };
    return [initial];
  });

  const [activeId, setActiveId] = useState<string>(systems[0]?.id || '');
  const activeSystem = systems.find(s => s.id === activeId);

  useEffect(() => {
    localStorage.setItem(`pump_${pumpType}_${auditId}`, JSON.stringify(systems));
  }, [systems, auditId, pumpType]);

  const updateActive = (updates: Partial<PumpData>) => {
    setSystems(prev => prev.map(s => s.id === activeId ? { ...s, ...updates } : s));
  };

  const updateUnit = (key: 'jockeyUnit' | 'dutyUnit' | 'standbyUnit', updates: Partial<PumpComponent>) => {
    if (!activeSystem) return;
    const current = (activeSystem as any)[key];
    if (current) updateActive({ [key]: { ...current, ...updates } });
  };

  const executeDelete = () => {
    if (!deleteTarget) return;
    if (systems.length <= 1) {
      alert("Sistem pam terakhir tidak boleh dipadam.");
      setDeleteTarget(null);
      return;
    }
    const newSystems = systems.filter(s => s.id !== deleteTarget.id);
    setSystems(newSystems);
    if (activeId === deleteTarget.id) {
      setActiveId(newSystems[0].id);
    }
    setDeleteTarget(null);
  };

  if (!activeSystem) return null;

  return (
    <div className="flex flex-col h-full bg-background-dark overflow-y-auto no-scrollbar pb-32">
      <TopBar title={`${pumpType.toUpperCase()} SYSTEM`} subtitle={`REF: ${auditId}`} showBack />
      
      <div className="p-4 flex flex-col gap-6 animate-in fade-in duration-500">
        {/* Tab Selector */}
        <section className="bg-surface-dark p-2 rounded-2xl border border-white/5 flex gap-2 overflow-x-auto no-scrollbar shadow-lg">
           {systems.map((s, idx) => (
              <div key={s.id} className="relative shrink-0 flex items-center">
                <button 
                  onClick={() => setActiveId(s.id)} 
                  className={`px-5 h-11 shrink-0 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 pr-10 ${activeId === s.id ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'bg-background-dark/50 text-text-muted hover:bg-white/5'}`}
                >
                  {s.systemName || `Set ${idx + 1}`}
                </button>
                {systems.length > 1 && (
                  <button 
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setDeleteTarget(s);
                    }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center text-white/30 hover:text-white transition-colors bg-white/5 hover:bg-red-500 rounded-full z-20"
                  >
                    <span className="material-symbols-outlined text-[14px]">close</span>
                  </button>
                )}
              </div>
           ))}
           <button onClick={() => { const ns = getBaseDefaults(systems.length); setSystems([...systems, ns]); setActiveId(ns.id); }} className="px-4 h-11 rounded-xl bg-white/5 text-primary flex items-center justify-center shrink-0 border border-white/5"><span className="material-symbols-outlined">add</span></button>
        </section>

        {/* Borang Detail */}
        <div className="flex flex-col gap-6">
          {/* PROFILE & RATINGS */}
          <section className="bg-primary/10 border border-primary/20 p-5 rounded-2xl flex flex-col gap-4 shadow-xl">
             <div className="flex justify-between items-center border-b border-primary/20 pb-3">
                <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">System Profile</h3>
                <select value={activeSystem.systemOverallStatus} onChange={(e) => updateActive({ systemOverallStatus: e.target.value as any })} className="bg-background-dark/50 border border-primary/40 rounded px-2 h-6 text-[8px] font-black uppercase text-white outline-none">
                  <option value="Normal">Normal</option><option value="Faulty">Faulty</option>
                </select>
             </div>
             <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase ml-1">System Name</label><input value={activeSystem.systemName} onChange={(e) => updateActive({ systemName: e.target.value })} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-[11px] font-bold text-white outline-none focus:ring-1 focus:ring-primary" placeholder="Set Name" /></div>
                <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase ml-1">Location</label><input value={activeSystem.location} onChange={(e) => updateActive({ location: e.target.value })} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-[11px] font-bold text-white outline-none focus:ring-1 focus:ring-primary" placeholder="Location" /></div>
             </div>
             <div className="grid grid-cols-3 gap-3">
                <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Jockey Rating</label><input value={activeSystem.jockeyRating} onChange={(e) => updateActive({ jockeyRating: e.target.value })} className="bg-background-dark border-none rounded-xl h-9 text-center text-[10px] font-bold text-primary" /></div>
                <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Motor Rating</label><input value={activeSystem.motorRating} onChange={(e) => updateActive({ motorRating: e.target.value })} className="bg-background-dark border-none rounded-xl h-9 text-center text-[10px] font-bold text-primary" /></div>
                <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Engine Rating</label><input value={activeSystem.engineRating} onChange={(e) => updateActive({ engineRating: e.target.value })} className="bg-background-dark border-none rounded-xl h-9 text-center text-[10px] font-bold text-primary" /></div>
             </div>
          </section>

          {/* PART I: METRICS */}
          <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
             <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">speed</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part I: Operating Metrics</h3></div>
             <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col gap-1.5"><label className="text-[8px] font-black text-text-muted uppercase tracking-widest ml-1">Header (Bar)</label><input type="text" value={activeSystem.headerPressure} onChange={(e) => updateActive({ headerPressure: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-sm font-black text-emerald-500 outline-none" /></div>
                <div className="flex flex-col gap-1.5"><label className="text-[8px] font-black text-text-muted uppercase tracking-widest ml-1">Tank Level</label><select value={activeSystem.tankLevel} onChange={(e) => updateActive({ tankLevel: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-xs font-bold text-white outline-none"><option>Full</option><option>75%</option><option>50%</option><option>Low</option></select></div>
             </div>
          </section>

          {/* PART II: MECHANICAL INTEGRITY */}
          <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
             <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">precision_manufacturing</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part II: Mechanical Integrity</h3></div>
             <div className="flex flex-col gap-4">
                <ToggleButton label="Pump Vibration" value={activeSystem.pumpVibration} options={['Normal', 'High']} onToggle={(v) => updateActive({ pumpVibration: v as any })} />
                <ToggleButton label="Pump Noise" value={activeSystem.pumpNoise} options={['Normal', 'Abnormal']} onToggle={(v) => updateActive({ pumpNoise: v as any })} />
                <ToggleButton label="Gland Packing" value={activeSystem.glandPacking} options={['Normal', 'Leaking']} onToggle={(v) => updateActive({ glandPacking: v as any })} />
                <ToggleButton label="Valve Status" value={activeSystem.valveCondition} options={['Normal', 'Fault']} onToggle={(v) => updateActive({ valveCondition: v as any })} />
             </div>
          </section>

          {/* PART III: PUMP UNITS */}
          <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
             <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">hub</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part III: Performance Verification</h3></div>
             <div className="flex flex-col gap-4">
                {!isHoseReel && activeSystem.jockeyUnit && <PumpUnitRow component={activeSystem.jockeyUnit} onUpdate={(upd) => updateUnit('jockeyUnit', upd)} />}
                {activeSystem.dutyUnit && <PumpUnitRow component={activeSystem.dutyUnit} onUpdate={(upd) => updateUnit('dutyUnit', upd)} />}
                {activeSystem.standbyUnit && <PumpUnitRow component={activeSystem.standbyUnit} onUpdate={(upd) => updateUnit('standbyUnit', upd)} isStandby />}
             </div>
          </section>

          {/* PART IV: PANEL INTEGRITY */}
          <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
             <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">electrical_services</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part IV: Control Panel Verification</h3></div>
             <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between"><span className="text-[9px] font-black uppercase text-white italic">Panel Incoming Voltage (V)</span><input type="text" value={activeSystem.panelIncomingVolt} onChange={(e) => updateActive({ panelIncomingVolt: e.target.value })} className="w-24 h-9 bg-background-dark border-none rounded-xl text-center text-[10px] font-black text-blue-400" /></div>
                <ToggleButton label="Indicator Lamps" value={activeSystem.panelLampsStatus} options={['Normal', 'Fault']} onToggle={(v) => updateActive({ panelLampsStatus: v as any })} />
                <ToggleButton label="Internal Wiring" value={activeSystem.panelWiringStatus} options={['Normal', 'Fault']} onToggle={(v) => updateActive({ panelWiringStatus: v as any })} />
                <ToggleButton label="Selector Switch" value={activeSystem.selectorSwitchStatus} options={['Normal', 'Fault']} onToggle={(v) => updateActive({ selectorSwitchStatus: v as any })} />
             </div>
          </section>

          {/* FINAL REMARKS */}
          <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
             <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">history_edu</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Final Verification Photos</h3></div>
             <textarea value={activeSystem.overallRemarks} onChange={(e) => updateActive({ overallRemarks: e.target.value })} className="w-full bg-background-dark/40 border-none rounded-2xl p-4 text-[11px] h-24 mb-4 text-white focus:ring-1 focus:ring-primary" placeholder="Summary of maintenance findings..." />
             <div className="grid grid-cols-4 gap-3">
                {activeSystem.servicePhotos.map((photo, idx) => (
                  <PhotoCaptureBox key={idx} photo={photo} onCapture={async (p) => {
                     const cp = await compressImage(p);
                     const n = [...activeSystem.servicePhotos]; n[idx] = cp; updateActive({ servicePhotos: n });
                  }} />
                ))}
             </div>
          </section>
        </div>
      </div>

      {/* CUSTOM DELETE MODAL */}
      {deleteTarget && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-200">
           <div className="bg-surface-dark w-full max-sm rounded-[32px] border border-white/10 p-8 flex flex-col gap-6 shadow-2xl animate-in zoom-in-95">
              <div className="w-16 h-16 bg-red-500/20 rounded-2xl flex items-center justify-center text-red-500 mx-auto">
                 <span className="material-symbols-outlined text-3xl">delete_sweep</span>
              </div>
              <div className="text-center">
                 <h3 className="text-sm font-black uppercase tracking-widest text-white mb-2">PADAM SET PAM?</h3>
                 <p className="text-[10px] text-text-muted font-bold leading-relaxed">
                    Anda akan memadam checksheet pam untuk <br/>
                    <span className="text-white font-black">"{deleteTarget.systemName}"</span><br/>
                    secara kekal.
                 </p>
              </div>
              <div className="flex flex-col gap-3">
                 <button onClick={executeDelete} className="w-full h-14 bg-red-600 text-white font-black uppercase tracking-widest text-xs rounded-2xl shadow-lg active:scale-95 transition-all">YA, PADAM SET PAM</button>
                 <button onClick={() => setDeleteTarget(null)} className="w-full h-14 bg-white/5 text-text-muted font-black uppercase tracking-widest text-[10px] rounded-2xl active:scale-95 transition-all">BATALKAN</button>
              </div>
           </div>
        </div>
      )}

      <div className="fixed bottom-0 w-full max-w-md bg-surface-dark border-t border-white/5 p-5 pb-10 z-50 shadow-2xl">
         <button onClick={() => navigate(`/checklist/${auditId}`)} className="w-full h-14 bg-primary text-white font-black uppercase tracking-[0.2em] text-xs rounded-xl shadow-2xl active:scale-[0.98] flex items-center justify-center gap-2"><span>Commit Technical Registry</span><span className="material-symbols-outlined text-sm">verified_user</span></button>
      </div>
    </div>
  );
};

const ToggleButton: React.FC<{ label: string; value: string; options: string[]; onToggle: (v: string) => void }> = ({ label, value, options, onToggle }) => (
  <div className="flex items-center justify-between">
    <span className="text-[9px] font-black uppercase text-white italic">{label}</span>
    <div className="flex gap-1.5 h-8">
      {options.map(opt => (
        <button key={opt} onClick={() => onToggle(opt)} className={`px-4 rounded-lg text-[7px] font-black uppercase transition-all ${value === opt ? (['Normal', 'Clean', 'Intact', 'Secure'].includes(opt) ? 'bg-emerald-600' : 'bg-primary') + ' text-white shadow-lg' : 'bg-background-dark/50 text-text-muted hover:bg-white/5'}`}>{opt}</button>
      ))}
    </div>
  </div>
);

const PumpUnitRow: React.FC<{ component: PumpComponent; onUpdate: (upd: Partial<PumpComponent>) => void; isStandby?: boolean }> = ({ component, onUpdate }) => {
  const isFault = component.status === 'Fault';
  return (
    <div className={`p-4 rounded-xl border transition-all ${isFault ? 'bg-primary/5 border-primary/20' : 'bg-background-dark/30 border-white/5 shadow-inner'}`}>
       <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between pb-2 border-b border-white/5">
             <span className="text-[10px] font-black text-white italic uppercase">{component.label}</span>
             <div className="flex gap-1.5 h-7">{(['Normal', 'Fault'] as const).map(s => (<button key={s} onClick={() => onUpdate({ status: s })} className={`px-3 rounded-lg text-[7px] font-black uppercase transition-all ${component.status === s ? (s === 'Normal' ? 'bg-emerald-600 shadow-md' : 'bg-primary shadow-md') + ' text-white' : 'bg-background-dark text-text-muted'}`}>{s}</button>))}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
             <div className="flex flex-col gap-1"><span className="text-[7px] font-black uppercase text-text-muted ml-1">Mode</span><select value={component.mode} onChange={(e) => onUpdate({ mode: e.target.value as any })} className="bg-background-dark border-none rounded-lg h-9 px-2 text-[9px] font-black uppercase text-primary outline-none"><option>Auto</option><option>Manual</option><option>Off</option></select></div>
             <div className="flex flex-col gap-1"><span className="text-[7px] font-black uppercase text-text-muted ml-1">Cut-In (Bar)</span><input type="text" value={component.cutIn} onChange={(e) => onUpdate({ cutIn: e.target.value })} className="bg-background-dark border-none rounded-lg h-9 px-2 text-center text-[10px] font-black text-emerald-500" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
             <div className="flex flex-col gap-1"><span className="text-[7px] font-black uppercase text-text-muted ml-1">Cut-Out (Bar)</span><input type="text" value={component.cutOut} onChange={(e) => onUpdate({ cutOut: e.target.value })} className="bg-background-dark border-none rounded-lg h-9 px-2 text-center text-[10px] font-black text-emerald-500" /></div>
             <div className="flex flex-col gap-1"><span className="text-[7px] font-black uppercase text-text-muted ml-1">{component.type === 'Electric' ? 'Load (Amp)' : 'Fuel (%)'}</span><input type="text" value={component.loadValue} onChange={(e) => onUpdate({ loadValue: e.target.value })} className="bg-background-dark border-none rounded-lg h-9 px-2 text-center text-[10px] font-black text-amber-500" /></div>
          </div>
          {isFault && (
            <div className="flex gap-2 mt-1 animate-in slide-in-from-top">
               <PhotoCaptureBox photo={component.photo} onCapture={async (p) => { const cp = await compressImage(p); onUpdate({ photo: cp }); }} />
               <textarea value={component.remarks || ''} onChange={(e) => onUpdate({ remarks: e.target.value })} className="flex-1 bg-background-dark/50 border-none rounded-lg p-2 text-[8px] text-white italic h-16 outline-none focus:ring-1 focus:ring-primary" placeholder="Describe the unit fault..." />
            </div>
          )}
       </div>
    </div>
  );
};

const PhotoCaptureBox: React.FC<{ photo?: string; onCapture: (p: string) => void; className?: string }> = ({ photo, onCapture, className }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onCapture(reader.result as string);
      reader.readAsDataURL(file);
    }
  };
  return (
    <div onClick={() => fileRef.current?.click()} className="w-16 h-16 bg-background-dark rounded-xl border border-primary/20 flex items-center justify-center overflow-hidden shrink-0 cursor-pointer shadow-inner relative group active:scale-95 transition-all">
      {photo ? <img src={photo} className="w-full h-full object-cover" /> : <span className="material-symbols-outlined text-primary/40 text-lg">add_a_photo</span>}
      <input type="file" ref={fileRef} className="hidden" accept="image/*" onChange={handleFile} />
    </div>
  );
};

export default PumpSystem;
