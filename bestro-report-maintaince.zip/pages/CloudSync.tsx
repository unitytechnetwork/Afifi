
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import TopBar from '../components/TopBar';
import BottomNav from '../components/BottomNav';
import { MOCK_USER } from '../constants';

interface TeamActivity {
  id: string;
  user: string;
  action: string;
  target: string;
  time: string;
  role: string;
}

const CloudSync: React.FC = () => {
  const navigate = useNavigate();
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [lastSync, setLastSync] = useState(localStorage.getItem('last_cloud_sync') || 'Never');
  
  const currentUser = useMemo(() => {
    const saved = localStorage.getItem('current_user');
    return saved ? JSON.parse(saved) : MOCK_USER;
  }, []);

  const [activities, setActivities] = useState<TeamActivity[]>([]);

  useEffect(() => {
    // Load simulated activity feed
    const feed = JSON.parse(localStorage.getItem('team_activity_feed') || '[]');
    setActivities(feed.slice(0, 10));
  }, []);

  const handlePushSync = () => {
    setIsSyncing(true);
    setSyncProgress(0);
    
    // Simulate Data Packaging
    const interval = setInterval(() => {
      setSyncProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          finalizeSync();
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  const finalizeSync = () => {
    const today = new Date().toLocaleString();
    localStorage.setItem('last_cloud_sync', today);
    setLastSync(today);

    // Update Global Cloud Vault (Simulated)
    const vault = JSON.parse(localStorage.getItem('global_cloud_vault') || '{}');
    const localKeys = Object.keys(localStorage).filter(k => k.includes('AUDIT-'));
    
    localKeys.forEach(key => {
      const auditId = key.split('_').pop()!;
      if (!vault[auditId]) vault[auditId] = {};
      vault[auditId][currentUser.id] = localStorage.getItem(key);
    });
    
    localStorage.setItem('global_cloud_vault', JSON.stringify(vault));

    // Update Activity Feed
    const feed = JSON.parse(localStorage.getItem('team_activity_feed') || '[]');
    feed.unshift({
      id: Date.now().toString(),
      user: currentUser.name,
      role: currentUser.role,
      action: 'Synchronized Dataset',
      target: `${localKeys.length / 2} Audits`,
      time: 'Just Now'
    });
    localStorage.setItem('team_activity_feed', JSON.stringify(feed.slice(0, 20)));
    setActivities(feed.slice(0, 10));

    setTimeout(() => {
      setIsSyncing(false);
      setSyncProgress(0);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-background-dark pb-32 overflow-hidden">
      <TopBar title="Engineering Cloud" subtitle="Enterprise Sync Hub" showBack />

      <div className="flex-1 overflow-y-auto no-scrollbar p-5 flex flex-col gap-6">
        
        {/* Connection Status Card */}
        <div className="bg-surface-dark p-6 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden">
           <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-3xl" />
           
           <div className="flex justify-between items-center mb-6 relative z-10">
              <div className="flex flex-col">
                 <p className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em]">Network Status</p>
                 <h2 className="text-xl font-black italic uppercase text-white tracking-tight">System Online</h2>
              </div>
              <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-500 border border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.2)]">
                 <span className="material-symbols-outlined text-2xl font-bold animate-pulse">cloud_queue</span>
              </div>
           </div>

           <div className="flex flex-col gap-4 relative z-10">
              <div className="flex justify-between items-center px-1">
                 <span className="text-[9px] font-black text-text-muted uppercase tracking-widest">Last Server Handshake</span>
                 <span className="text-[10px] font-black text-white italic">{lastSync}</span>
              </div>
              
              {isSyncing ? (
                 <div className="flex flex-col gap-3 animate-in fade-in">
                    <div className="h-2 w-full bg-background-dark rounded-full overflow-hidden border border-white/5">
                       <div className="h-full bg-primary transition-all" style={{ width: `${syncProgress}%` }} />
                    </div>
                    <div className="flex justify-between items-center">
                       <span className="text-[8px] font-black text-primary uppercase tracking-widest animate-pulse">Encrypting Payload...</span>
                       <span className="text-[10px] font-black text-white">{syncProgress}%</span>
                    </div>
                 </div>
              ) : (
                 <button 
                   onClick={handlePushSync}
                   className="w-full h-14 bg-primary text-white font-black uppercase tracking-[0.2em] text-xs rounded-2xl shadow-xl shadow-primary/20 active:scale-95 transition-all flex items-center justify-center gap-3"
                 >
                    <span className="material-symbols-outlined">sync</span>
                    Force Global Sync
                 </button>
              )}
           </div>
        </div>

        {/* Cloud Stats */}
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-surface-dark p-5 rounded-3xl border border-white/5 flex flex-col gap-1">
              <span className="text-[8px] font-black text-text-muted uppercase tracking-widest">Team Users</span>
              <span className="text-xl font-black text-white italic">12 Online</span>
           </div>
           <div className="bg-surface-dark p-5 rounded-3xl border border-white/5 flex flex-col gap-1">
              <span className="text-[8px] font-black text-text-muted uppercase tracking-widest">Cloud Storage</span>
              <span className="text-xl font-black text-white italic">245 MB Used</span>
           </div>
        </div>

        {/* Team Activity Feed */}
        <div className="flex flex-col gap-4 flex-1">
           <div className="flex justify-between items-center px-2">
              <h3 className="text-[10px] font-black text-text-muted uppercase tracking-[0.3em] italic">Team Activity Feed</h3>
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
           </div>

           <div className="flex flex-col gap-3">
              {activities.length > 0 ? activities.map(act => (
                <div key={act.id} className="bg-surface-dark p-4 rounded-2xl border border-white/5 flex items-start gap-4 shadow-lg group">
                   <div className="w-10 h-10 rounded-xl bg-background-dark flex items-center justify-center text-primary border border-white/5 group-hover:bg-primary group-hover:text-white transition-all">
                      <span className="material-symbols-outlined text-xl">person</span>
                   </div>
                   <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-0.5">
                         <h4 className="text-[11px] font-bold text-white uppercase truncate">{act.user}</h4>
                         <span className="text-[7px] font-black text-text-muted uppercase">{act.time}</span>
                      </div>
                      <p className="text-[9px] text-text-muted font-medium mb-1">{act.action} on <span className="text-white font-bold">{act.target}</span></p>
                      <span className="text-[7px] font-black text-primary bg-primary/10 px-1.5 py-0.5 rounded uppercase tracking-tighter">{act.role}</span>
                   </div>
                </div>
              )) : (
                <div className="py-20 flex flex-col items-center justify-center opacity-10 grayscale">
                   <span className="material-symbols-outlined text-6xl">leak_remove</span>
                   <p className="text-[10px] font-black uppercase tracking-[0.4em] mt-4">No Remote Activity</p>
                </div>
              )}
           </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
};

export default CloudSync;
