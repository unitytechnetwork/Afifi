
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import TopBar from '../components/TopBar';
import BottomNav from '../components/BottomNav';
import { InspectionStatus } from '../types';

interface ScheduledTask {
  id: string;
  clientName: string;
  location: string;
  lastServiceDate: string;
  nextDueDate: string;
  daysRemaining: number;
  status: 'OVERDUE' | 'DUE_SOON' | 'PLANNED';
  assignedTech: string;
  cycle: string;
}

const Scheduler: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState<ScheduledTask[]>([]);
  const [filter, setFilter] = useState<'ALL' | 'OVERDUE' | 'DUE_SOON'>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Form State for Manual Schedule
  const [newSchedule, setNewSchedule] = useState({
    clientName: '',
    location: '',
    nextDueDate: new Date().toISOString().split('T')[0],
    assignedTech: '',
    cycle: 'Cycle 1'
  });

  useEffect(() => {
    const loadSchedules = () => {
      const allTasks: ScheduledTask[] = [];
      const keys = Object.keys(localStorage);
      const today = new Date();

      keys.forEach(key => {
        if (key.startsWith('setup_AUDIT-')) {
          try {
            const data = JSON.parse(localStorage.getItem(key) || '{}');
            if (data.nextServiceDate) {
              const dueDate = new Date(data.nextServiceDate);
              const diffTime = dueDate.getTime() - today.getTime();
              const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

              let status: 'OVERDUE' | 'DUE_SOON' | 'PLANNED' = 'PLANNED';
              if (diffDays < 0) status = 'OVERDUE';
              else if (diffDays <= 14) status = 'DUE_SOON';

              allTasks.push({
                id: key.replace('setup_', ''),
                clientName: data.clientName || 'Unnamed Site',
                location: data.location || 'Unknown',
                lastServiceDate: data.date || '-',
                nextDueDate: data.nextServiceDate,
                daysRemaining: diffDays,
                status,
                assignedTech: data.techName || 'Unassigned',
                cycle: data.frequency || 'Cycle 1'
              });
            }
          } catch (e) {}
        }
      });

      setTasks(allTasks.sort((a, b) => a.daysRemaining - b.daysRemaining));
    };

    loadSchedules();
  }, [refreshTrigger]);

  const handleAddSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSchedule.clientName || !newSchedule.nextDueDate) return;

    const auditId = `AUDIT-SCHEDULED-${Date.now()}`;
    const setupData = {
      clientName: newSchedule.clientName,
      location: newSchedule.location,
      date: new Date().toISOString().split('T')[0],
      nextServiceDate: newSchedule.nextDueDate,
      frequency: newSchedule.cycle,
      techName: newSchedule.assignedTech || 'TBA',
      status: InspectionStatus.DRAFT
    };

    localStorage.setItem(`setup_${auditId}`, JSON.stringify(setupData));
    setRefreshTrigger(prev => prev + 1);
    setShowAddModal(false);
    setNewSchedule({ clientName: '', location: '', nextDueDate: new Date().toISOString().split('T')[0], assignedTech: '', cycle: 'Cycle 1' });
  };

  const filteredTasks = useMemo(() => {
    if (filter === 'ALL') return tasks;
    return tasks.filter(t => t.status === filter);
  }, [tasks, filter]);

  const stats = useMemo(() => ({
    overdue: tasks.filter(t => t.status === 'OVERDUE').length,
    dueSoon: tasks.filter(t => t.status === 'DUE_SOON').length,
    total: tasks.length
  }), [tasks]);

  return (
    <div className="flex flex-col h-full bg-background-dark pb-32 overflow-hidden">
      <TopBar title="Service Scheduler" subtitle="Maintenance Lifecycle" />
      
      <div className="flex-1 p-4 flex flex-col gap-6 overflow-y-auto no-scrollbar">
        {/* Analytics Header */}
        <div className="bg-surface-dark p-6 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden shrink-0">
           <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16 blur-3xl" />
           
           <div className="flex justify-between items-center mb-6 relative z-10">
              <div className="flex flex-col">
                 <p className="text-[10px] font-black text-text-muted uppercase tracking-[0.2em]">Operational Pipeline</p>
                 <h2 className="text-xl font-black italic uppercase text-white tracking-tight">Active Schedule</h2>
              </div>
              <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center text-primary border border-primary/20">
                 <span className="material-symbols-outlined">calendar_month</span>
              </div>
           </div>

           <div className="grid grid-cols-3 gap-3 relative z-10">
              <button onClick={() => setFilter('OVERDUE')} className={`p-3 rounded-2xl border flex flex-col items-center transition-all ${filter === 'OVERDUE' ? 'bg-primary border-primary' : 'bg-background-dark/50 border-white/5'}`}>
                 <span className={`text-xl font-black ${filter === 'OVERDUE' ? 'text-white' : 'text-primary'}`}>{stats.overdue}</span>
                 <span className={`text-[7px] font-black uppercase ${filter === 'OVERDUE' ? 'text-white/70' : 'text-text-muted'}`}>Overdue</span>
              </button>
              <button onClick={() => setFilter('DUE_SOON')} className={`p-3 rounded-2xl border flex flex-col items-center transition-all ${filter === 'DUE_SOON' ? 'bg-amber-600 border-amber-600' : 'bg-background-dark/50 border-white/5'}`}>
                 <span className={`text-xl font-black ${filter === 'DUE_SOON' ? 'text-white' : 'text-amber-500'}`}>{stats.dueSoon}</span>
                 <span className={`text-[7px] font-black uppercase ${filter === 'DUE_SOON' ? 'text-white/70' : 'text-text-muted'}`}>Due Soon</span>
              </button>
              <button onClick={() => setFilter('ALL')} className={`p-3 rounded-2xl border flex flex-col items-center transition-all ${filter === 'ALL' ? 'bg-emerald-600 border-emerald-600' : 'bg-background-dark/50 border-white/5'}`}>
                 <span className={`text-xl font-black ${filter === 'ALL' ? 'text-white' : 'text-emerald-500'}`}>{stats.total}</span>
                 <span className={`text-[7px] font-black uppercase ${filter === 'ALL' ? 'text-white/70' : 'text-text-muted'}`}>Total</span>
              </button>
           </div>
        </div>

        {/* Task Feed */}
        <div className="flex flex-col gap-4">
           <div className="flex justify-between items-center px-2">
             <h3 className="text-[10px] font-black text-text-muted uppercase tracking-[0.3em] italic">Service Lifecycle Feed</h3>
             <button onClick={() => setShowAddModal(true)} className="text-[8px] font-black uppercase bg-primary/10 text-primary border border-primary/20 px-3 py-1 rounded-lg">+ Add Manual</button>
           </div>
           
           {filteredTasks.length > 0 ? filteredTasks.map((task) => (
             <div key={task.id} className="bg-surface-dark rounded-[2rem] border border-white/5 p-5 shadow-xl group relative overflow-hidden active:scale-[0.98] transition-all">
                <div className={`absolute top-0 left-0 w-1.5 h-full ${task.status === 'OVERDUE' ? 'bg-primary' : task.status === 'DUE_SOON' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                
                <div className="flex justify-between items-start mb-4">
                   <div className="flex-1 min-w-0 pr-4">
                      <h4 className="text-sm font-bold text-white uppercase truncate tracking-tight">{task.clientName}</h4>
                      <p className="text-[9px] text-text-muted uppercase italic truncate mt-0.5">{task.location}</p>
                   </div>
                   <div className={`px-2 py-1 rounded-lg text-[7px] font-black uppercase tracking-widest border ${
                     task.status === 'OVERDUE' ? 'bg-primary/10 text-primary border-primary/20' : 
                     task.status === 'DUE_SOON' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 
                     'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                   }`}>
                      {task.status.replace('_', ' ')}
                   </div>
                </div>

                <div className="grid grid-cols-2 gap-4 py-3 border-y border-white/5 mb-4">
                   <div className="flex flex-col">
                      <span className="text-[7px] font-black text-text-muted uppercase tracking-widest">Next Service Due</span>
                      <span className={`text-xs font-black ${task.status === 'OVERDUE' ? 'text-primary' : 'text-white'}`}>{task.nextDueDate}</span>
                   </div>
                   <div className="flex flex-col items-end">
                      <span className="text-[7px] font-black text-text-muted uppercase tracking-widest">Time Remaining</span>
                      <span className={`text-xs font-black ${task.status === 'OVERDUE' ? 'text-primary' : 'text-emerald-500'}`}>
                         {task.daysRemaining < 0 ? `${Math.abs(task.daysRemaining)} Days Late` : `${task.daysRemaining} Days Left`}
                      </span>
                   </div>
                </div>

                <div className="flex items-center justify-between">
                   <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-background-dark border border-white/10 flex items-center justify-center">
                         <span className="material-symbols-outlined text-[14px] text-text-muted">person</span>
                      </div>
                      <span className="text-[9px] font-bold text-text-muted uppercase">{task.assignedTech}</span>
                   </div>
                   <button 
                     onClick={() => navigate(`/inspection-cover/${task.id}`)}
                     className="h-9 px-4 bg-white/5 border border-white/10 rounded-xl text-[9px] font-black uppercase tracking-widest text-white hover:bg-primary transition-all flex items-center gap-2"
                   >
                      <span className="material-symbols-outlined text-sm">edit_calendar</span>
                      Manage Service
                   </button>
                </div>
             </div>
           )) : (
             <div className="py-20 flex flex-col items-center justify-center opacity-20">
                <span className="material-symbols-outlined text-6xl">event_available</span>
                <p className="text-[10px] font-black uppercase tracking-widest mt-2">No Scheduled Tasks Found</p>
             </div>
           )}
        </div>
      </div>

      {/* Manual Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="bg-surface-dark w-full max-w-sm rounded-[32px] border border-white/10 p-8 flex flex-col gap-6 shadow-2xl animate-in zoom-in-95">
              <div className="flex justify-between items-center mb-2">
                 <div>
                    <h3 className="text-sm font-black uppercase tracking-widest italic text-primary">Schedule New Audit</h3>
                    <p className="text-[9px] text-text-muted font-black uppercase mt-1 tracking-widest">Manual Setup</p>
                 </div>
                 <button onClick={() => setShowAddModal(false)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/5"><span className="material-symbols-outlined">close</span></button>
              </div>

              <form onSubmit={handleAddSchedule} className="flex flex-col gap-4">
                 <div className="flex flex-col gap-1.5">
                    <label className="text-[8px] font-black text-text-muted uppercase ml-1">Building / Client Name</label>
                    <input required value={newSchedule.clientName} onChange={e => setNewSchedule({...newSchedule, clientName: e.target.value})} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-xs font-bold text-white outline-none focus:ring-1 focus:ring-primary" placeholder="e.g. Wisma Bestro" />
                 </div>
                 <div className="flex flex-col gap-1.5">
                    <label className="text-[8px] font-black text-text-muted uppercase ml-1">Building Location</label>
                    <input value={newSchedule.location} onChange={e => setNewSchedule({...newSchedule, location: e.target.value})} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-xs font-bold text-white outline-none focus:ring-1 focus:ring-primary" placeholder="e.g. Shah Alam" />
                 </div>
                 <div className="flex flex-col gap-1.5">
                    <label className="text-[8px] font-black text-primary uppercase ml-1 italic">Next Service Due Date</label>
                    <input type="date" required value={newSchedule.nextDueDate} onChange={e => setNewSchedule({...newSchedule, nextDueDate: e.target.value})} className="bg-background-dark/50 border-primary/20 border rounded-xl h-11 px-4 text-xs font-black text-emerald-500 outline-none" />
                 </div>
                 <div className="grid grid-cols-2 gap-3">
                   <div className="flex flex-col gap-1.5">
                      <label className="text-[8px] font-black text-text-muted uppercase ml-1">Assign Tech</label>
                      <input value={newSchedule.assignedTech} onChange={e => setNewSchedule({...newSchedule, assignedTech: e.target.value})} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-[10px] font-bold text-white outline-none" placeholder="Tech Name" />
                   </div>
                   <div className="flex flex-col gap-1.5">
                      <label className="text-[8px] font-black text-text-muted uppercase ml-1">Cycle</label>
                      <select value={newSchedule.cycle} onChange={e => setNewSchedule({...newSchedule, cycle: e.target.value})} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-[10px] font-bold text-white outline-none appearance-none">
                         <option>Cycle 1</option><option>Cycle 2</option><option>Cycle 3</option><option>Cycle 4</option>
                      </select>
                   </div>
                 </div>

                 <button type="submit" className="w-full h-14 bg-primary text-white font-black uppercase tracking-[0.2em] text-xs rounded-2xl shadow-xl active:scale-95 transition-all mt-4">Confirm Schedule Entry</button>
              </form>
           </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
};

export default Scheduler;
