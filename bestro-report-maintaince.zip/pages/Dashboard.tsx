
import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import TopBar from '../components/TopBar';
import BottomNav from '../components/BottomNav';
import { MOCK_USER } from '../constants';
import { InspectionStatus, User, Inspection } from '../types';
import { sendLocalNotification } from '../components/NotificationManager';

const Dashboard: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  
  // State untuk Modal Padam
  const [deleteTarget, setDeleteTarget] = useState<Inspection | null>(null);

  const [currentUser] = useState<User>(() => {
    const saved = localStorage.getItem('current_user');
    try {
      return saved ? JSON.parse(saved) : MOCK_USER;
    } catch {
      return MOCK_USER;
    }
  });

  const [localAudits, setLocalAudits] = useState<Inspection[]>([]);
  const isSupervisor = currentUser?.role === 'Supervisor' || currentUser?.role === 'Admin';

  // Cloud Sync Logic
  const cloudRegistry = useMemo(() => JSON.parse(localStorage.getItem('global_cloud_vault') || '{}'), [refreshTrigger]);

  useEffect(() => {
    const audits: Inspection[] = [];
    const keys = Object.keys(localStorage);
    
    keys.forEach(key => {
      if (key.startsWith('setup_AUDIT-')) {
        try {
          const rawData = localStorage.getItem(key);
          if (!rawData) return;
          const setupData = JSON.parse(rawData);
          const auditId = key.replace('setup_', '');
          
          audits.push({
            id: auditId,
            title: setupData.clientName || 'Draft Inspection',
            location: setupData.location || 'Location Not Set',
            date: setupData.date || 'No Date',
            status: setupData.status || InspectionStatus.DRAFT,
            itemsCompleted: 0,
            totalItems: 13,
            technician: setupData.techName || 'Unassigned',
            technicianId: setupData.technicianId ? String(setupData.technicianId) : undefined
          });
        } catch (e) {}
      }
    });

    const filtered = audits.filter(a => {
      if (isSupervisor) return true;
      return String(a.technicianId) === String(currentUser?.id);
    });

    setLocalAudits(filtered.sort((a, b) => b.id.localeCompare(a.id)));
  }, [currentUser, isSupervisor, refreshTrigger]);

  const groupedAudits = useMemo(() => {
    const filtered = localAudits.filter(a => 
      a.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      a.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.id.includes(searchTerm)
    );

    const groups: Record<string, Inspection[]> = {};
    filtered.forEach(audit => {
      const dateObj = new Date(audit.date);
      const monthYear = isNaN(dateObj.getTime()) 
        ? "TIADA TARIKH" 
        : dateObj.toLocaleString('ms-MY', { month: 'long', year: 'numeric' }).toUpperCase();
      
      if (!groups[monthYear]) groups[monthYear] = [];
      groups[monthYear].push(audit);
    });
    return groups;
  }, [localAudits, searchTerm]);

  // Fungsi Klon
  const handleCloneAudit = (oldAuditId: string) => {
    if (!window.confirm("Klon data aset ke audit baru? Status kerosakan akan di-reset untuk bulan baru.")) return;

    const newAuditId = `AUDIT-${Date.now()}`;
    const prefixes = [
      'setup_', 'checklist_', 'gas_suppression_', 'pump_hosereel_', 
      'pump_wetriser_', 'pump_hydrant_', 'pump_sprinkler_', 
      'equip_hosereel_', 'equip_hydrant_', 'equip_wetriser_', 
      'equip_dryriser_', 'extinguisher_', 'light_emergency_', 'light_keluar_'
    ];

    prefixes.forEach(prefix => {
      const oldRaw = localStorage.getItem(`${prefix}${oldAuditId}`);
      if (oldRaw) {
        let parsed = JSON.parse(oldRaw);
        if (prefix !== 'setup_') {
          const resetFn = (item: any) => {
            if (typeof item !== 'object' || item === null) return item;
            const clean = { ...item };
            if (clean.photos) clean.photos = {};
            if (clean.servicePhotos) clean.servicePhotos = ['', '', '', ''];
            if (clean.remarks) clean.remarks = typeof clean.remarks === 'object' ? {} : '';
            
            const statusFields = ['status', 'systemOverallStatus', 'condition', 'testOutcome', 'pressure', 'pin', 'cableTie', 'bombaCert', 'physicalBody'];
            statusFields.forEach(f => { 
              if (clean[f]) {
                 if (['Normal', 'Good', 'Intact', 'Valid'].includes(clean[f])) return;
                 if (f === 'pressure') clean[f] = 'Normal';
                 else if (f === 'pin') clean[f] = 'Intact';
                 else if (f === 'bombaCert') clean[f] = 'Valid';
                 else clean[f] = 'Normal';
              }
            });
            return clean;
          };
          if (Array.isArray(parsed)) parsed = parsed.map(resetFn);
          else if (parsed.items) parsed.items = parsed.items.map(resetFn);
          else parsed = resetFn(parsed);
        } else {
          parsed.status = InspectionStatus.DRAFT;
          parsed.date = new Date().toISOString().split('T')[0];
          parsed.techSigData = '';
          parsed.clientSigData = '';
        }
        localStorage.setItem(`${prefix}${newAuditId}`, JSON.stringify(parsed));
      }
    });

    setRefreshTrigger(prev => prev + 1);
    navigate(`/inspection-cover/${newAuditId}`);
  };

  const executeDelete = () => {
    if (!deleteTarget) return;
    const auditId = deleteTarget.id;
    const allKeys = Object.keys(localStorage);
    allKeys.forEach(key => { if (key.includes(auditId)) localStorage.removeItem(key); });
    setLocalAudits(prev => prev.filter(a => a.id !== auditId));
    sendLocalNotification("Dihapuskan", `Rekod untuk ${deleteTarget.title} telah dipadam.`);
    setDeleteTarget(null);
  };

  return (
    <div className="flex flex-col h-full bg-background-dark pb-24 overflow-y-auto no-scrollbar">
      <TopBar 
        title={t('bottom_nav.dashboard')} 
        onSave={() => navigate('/cloud-sync')} 
      />
      
      <div className="p-4 flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <h1 className="text-2xl font-black italic uppercase tracking-tight text-white leading-none">TERMINAL AKTIF</h1>
            <div className="flex items-center gap-2 mt-1">
               <span className="text-emerald-500 material-symbols-outlined text-xs animate-pulse">cloud_done</span>
               <p className="text-text-muted font-black text-[9px] uppercase tracking-widest">{currentUser.name} • <span className="text-primary">{currentUser.role}</span></p>
            </div>
          </div>
          <div className="flex items-center gap-3">
             <button onClick={() => navigate('/cloud-sync')} className="w-10 h-10 bg-surface-dark border border-white/5 rounded-xl flex items-center justify-center text-primary shadow-lg">
                <span className="material-symbols-outlined">sync</span>
             </button>
             <div onClick={() => navigate('/settings')} className="w-12 h-12 rounded-full border-2 border-primary bg-surface-dark bg-cover bg-center shadow-lg cursor-pointer" style={{ backgroundImage: `url(${currentUser.avatar})` }} />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
           <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-text-muted text-lg">search</span>
           <input 
             type="text" 
             placeholder="Cari Site, Bangunan atau ID..."
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full h-14 bg-surface-dark border-white/5 border rounded-2xl pl-12 pr-4 text-sm font-bold text-white focus:ring-1 focus:ring-primary outline-none shadow-xl"
           />
        </div>

        {/* Month Folders */}
        <div className="flex flex-col gap-8">
          {Object.keys(groupedAudits).length > 0 ? (Object.entries(groupedAudits) as [string, Inspection[]][]).map(([month, audits]) => (
            <div key={month} className="flex flex-col gap-3">
               <div className="flex items-center gap-3 px-1">
                  <div className="h-4 w-1 bg-primary rounded-full" />
                  <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-text-muted italic">{month}</h3>
                  <div className="h-[1px] flex-1 bg-white/5" />
                  <span className="text-[8px] font-black text-white/20 bg-white/5 px-2 py-0.5 rounded-full uppercase">{audits.length} Site Detected</span>
               </div>

               <div className="flex flex-col gap-3">
                 {audits.map((insp) => {
                    const isSynced = cloudRegistry[insp.id];
                    return (
                      <div 
                        key={insp.id} 
                        className={`bg-surface-dark rounded-2xl border flex flex-col shadow-lg overflow-hidden group transition-all ${insp.status === InspectionStatus.APPROVED ? 'border-emerald-500/30' : 'border-white/5'}`}
                      >
                        <div 
                           onClick={() => navigate(`/inspection-cover/${insp.id}`)}
                           className="p-4 flex flex-col gap-3 active:bg-white/5 transition-colors cursor-pointer"
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex gap-3 min-w-0">
                              <div className="relative shrink-0">
                                <div className="w-11 h-11 rounded-xl bg-background-dark flex items-center justify-center shadow-inner">
                                   <span className={`material-symbols-outlined ${insp.status === InspectionStatus.APPROVED ? 'text-emerald-500' : 'text-primary'}`}>corporate_fare</span>
                                </div>
                                {isSynced && (
                                   <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-surface-dark flex items-center justify-center">
                                      <span className="material-symbols-outlined text-[8px] text-white font-black">cloud_done</span>
                                   </div>
                                )}
                              </div>
                              <div className="min-w-0">
                                <h4 className="font-bold text-xs truncate uppercase tracking-tight text-white">{insp.title}</h4>
                                <p className="text-[9px] text-text-muted uppercase truncate italic">{insp.location}</p>
                              </div>
                            </div>
                            <div className={`px-2 py-0.5 rounded-lg text-[7px] font-black border shrink-0 ${insp.status === InspectionStatus.SUBMITTED || insp.status === InspectionStatus.APPROVED ? 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' : 'text-slate-400 bg-slate-400/10 border-slate-400/20'}`}>{insp.status}</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between px-4 pb-4 border-t border-white/5 pt-3">
                           <div className="flex gap-2">
                              <button onClick={() => handleCloneAudit(insp.id)} className="h-9 px-4 bg-primary/10 active:bg-primary/30 rounded-xl text-primary text-[8px] font-black uppercase tracking-widest flex items-center gap-2 transition-all"><span className="material-symbols-outlined text-sm">content_copy</span> KLON</button>
                              <button onClick={() => setDeleteTarget(insp)} className="h-9 w-9 bg-white/5 active:bg-red-500/30 rounded-xl text-text-muted hover:text-red-500 flex items-center justify-center transition-all border border-transparent hover:border-red-500/30"><span className="material-symbols-outlined text-sm">delete</span></button>
                           </div>
                           <div onClick={() => navigate(`/inspection-cover/${insp.id}`)} className="flex items-center text-primary text-[9px] font-black uppercase">BUKA <span className="material-symbols-outlined text-sm">chevron_right</span></div>
                        </div>
                      </div>
                    );
                 })}
               </div>
            </div>
          )) : (
            <div className="py-20 text-center opacity-20 flex flex-col items-center">
               <span className="material-symbols-outlined text-5xl">folder_off</span>
               <p className="text-[10px] font-black uppercase mt-2 tracking-widest">Tiada Site Dijumpai</p>
            </div>
          )}
        </div>
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-200">
           <div className="bg-surface-dark w-full max-w-sm rounded-[32px] border border-white/10 p-8 flex flex-col gap-6 shadow-2xl animate-in zoom-in-95">
              <div className="w-16 h-16 bg-red-500/20 rounded-2xl flex items-center justify-center text-red-500 mx-auto">
                 <span className="material-symbols-outlined text-3xl">delete_forever</span>
              </div>
              <div className="text-center">
                 <h3 className="text-sm font-black uppercase tracking-widest text-white mb-2">PADAM REKOD SITE?</h3>
                 <p className="text-[10px] text-text-muted font-bold leading-relaxed">Anda akan memadam rekod untuk <br/><span className="text-white font-black">"{deleteTarget.title}"</span><br/>secara kekal. Tindakan ini tidak boleh dibatalkan.</p>
              </div>
              <div className="flex flex-col gap-3">
                 <button onClick={executeDelete} className="w-full h-14 bg-red-600 text-white font-black uppercase tracking-widest text-xs rounded-2xl shadow-lg active:scale-95 transition-all">YA, PADAM SEKARANG</button>
                 <button onClick={() => setDeleteTarget(null)} className="w-full h-14 bg-white/5 text-text-muted font-black uppercase tracking-widest text-[10px] rounded-2xl active:scale-95 transition-all">BATALKAN</button>
              </div>
           </div>
        </div>
      )}

      <button onClick={() => navigate(`/inspection-cover/AUDIT-${Date.now()}`)} className="fixed bottom-24 right-5 w-16 h-16 bg-primary text-white rounded-2xl shadow-2xl flex flex-col items-center justify-center z-40 active:scale-90 transition-all border-4 border-background-dark">
        <span className="material-symbols-outlined text-2xl">add</span>
        <span className="text-[7px] font-black uppercase tracking-widest text-white">Baru</span>
      </button>

      <BottomNav />
    </div>
  );
};

export default Dashboard;
