
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TopBar from '../components/TopBar';

// Helper: Compress Image
const compressImage = (base64Str: string, maxWidth = 1024, quality = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
  });
};

interface IntegrationItem {
  id: string;
  label: string;
  status: 'Functional' | 'Faulty' | 'N/A';
  photo?: string;
  remarks?: string;
}

interface GasSystemEntry {
  id: string;
  panelModel: string;
  zoneName: string;
  cylinderSerial: string;
  cylinderQty: string;
  cylinderMfgDate: string; // Year and Month of manufacture
  cylinderHydroDate: string; // Hydrostatic test date
  dischargeTimer: string;
  batteryVolt: string;
  chargerVolt: string;
  agentType: string;
  
  // Custom field for "Other" agent type
  otherAgentPhoto?: string;
  otherAgentRemark?: string;
  
  // Device Quantities
  smokeQty: string;
  heatQty: string;
  flashingLightQty: string;
  bellQty: string;
  blanketQty: string;

  // Device Statuses
  smokeStatus: 'Normal' | 'Fault';
  heatStatus: 'Normal' | 'Fault';
  bellStatus: 'Normal' | 'Fault';
  flashingLightStatus: 'Normal' | 'Fault';
  blanketStatus: 'Normal' | 'Fault';
  batteryStatus: 'Normal' | 'Fault';
  pipingStatus: 'Normal' | 'Fault';
  nozzleStatus: 'Normal' | 'Fault';

  integrationItems: IntegrationItem[];
  systemDescription: string;
  systemOverallStatus: 'Normal' | 'Faulty' | 'Partial' | 'N/A';
  
  // Specific Remarks/Photos for devices
  deviceRemarks: Record<string, string>;
  devicePhotos: Record<string, string>;
  
  overallRemarks: string;
  servicePhotos: string[];
}

const GasSuppression: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const auditId = id || 'NEW-AUDIT';

  const [deleteTarget, setDeleteTarget] = useState<GasSystemEntry | null>(null);

  const gasOptions = [
    'FM-200 (HFC-227ea)',
    'Novec 1230 (FK-5-1-12)',
    'CO2 (Carbon Dioxide)',
    'Inergen (IG-541)',
    'Argonite (IG-55)',
    'Aerosol System',
    'Lain-lain (Others)'
  ];

  const defaultIntegrationItems: IntegrationItem[] = [
    { id: 'bell_switch', label: 'Bell Switch Control', status: 'Functional' },
    { id: 'buzzer', label: 'Internal Buzzer Health', status: 'Functional' },
    { id: 'abort', label: 'Abort Switch Health', status: 'Functional' },
    { id: 'manual_release', label: 'Manual Release Health', status: 'Functional' },
  ];

  const getDefaultSystem = (): GasSystemEntry => ({
    id: Date.now().toString(),
    panelModel: 'Morley Gas Panel',
    zoneName: 'Server Room',
    cylinderSerial: '',
    cylinderQty: '1',
    cylinderMfgDate: '', 
    cylinderHydroDate: '',
    dischargeTimer: '30',
    batteryVolt: '27.2',
    chargerVolt: '27.4',
    agentType: gasOptions[0],
    
    otherAgentPhoto: '',
    otherAgentRemark: '',
    
    smokeQty: '0', heatQty: '0', flashingLightQty: '0', bellQty: '0', blanketQty: '0',
    
    smokeStatus: 'Normal', heatStatus: 'Normal', bellStatus: 'Normal',
    flashingLightStatus: 'Normal', blanketStatus: 'Normal',
    batteryStatus: 'Normal', pipingStatus: 'Normal', nozzleStatus: 'Normal',

    integrationItems: [...defaultIntegrationItems],
    systemDescription: 'Maintenance and integrity verification of gas suppression system.',
    systemOverallStatus: 'Normal',
    deviceRemarks: {},
    devicePhotos: {},
    overallRemarks: '',
    servicePhotos: ['', '', '', '']
  });

  const [systems, setSystems] = useState<GasSystemEntry[]>(() => {
    const saved = localStorage.getItem(`gas_suppression_${auditId}`);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const dataArr = Array.isArray(parsed) ? parsed : [parsed];
        return dataArr.map((s: any) => ({ ...getDefaultSystem(), ...s }));
      } catch (e) { console.error(e); }
    }
    return [getDefaultSystem()];
  });

  const [activeSystemId, setActiveSystemId] = useState<string>(systems[0]?.id || '');
  const activeSystem = systems.find(s => s.id === activeSystemId);

  useEffect(() => {
    localStorage.setItem(`gas_suppression_${auditId}`, JSON.stringify(systems));
  }, [systems, auditId]);

  const updateActiveSystem = (updates: Partial<GasSystemEntry>) => {
    setSystems(prev => prev.map(s => s.id === activeSystemId ? { ...s, ...updates } : s));
  };

  // NEW: Logic for auto-calculating hydro date (10 years)
  const handleMfgDateChange = (val: string) => {
    if (val) {
      const [year, month] = val.split('-');
      const nextYear = parseInt(year) + 10;
      const hydroDate = `${nextYear}-${month}`;
      updateActiveSystem({ 
        cylinderMfgDate: val,
        cylinderHydroDate: hydroDate 
      });
    } else {
      updateActiveSystem({ cylinderMfgDate: val });
    }
  };

  const updateDeviceDetail = (key: string, field: 'status' | 'remark' | 'photo', value: string) => {
    if (!activeSystem) return;
    if (field === 'status') {
      updateActiveSystem({ [key + 'Status']: value } as any);
    } else if (field === 'remark') {
      updateActiveSystem({ deviceRemarks: { ...activeSystem.deviceRemarks, [key]: value } });
    } else if (field === 'photo') {
      updateActiveSystem({ devicePhotos: { ...activeSystem.devicePhotos, [key]: value } });
    }
  };

  const executeDelete = () => {
    if (!deleteTarget) return;
    if (systems.length <= 1) {
      alert("Sistem terakhir tidak boleh dipadam.");
      setDeleteTarget(null);
      return;
    }
    const newSystems = systems.filter(s => s.id !== deleteTarget.id);
    setSystems(newSystems);
    if (activeSystemId === deleteTarget.id) setActiveSystemId(newSystems[0].id);
    setDeleteTarget(null);
  };

  if (!activeSystem) return null;

  return (
    <div className="flex flex-col h-full bg-background-dark overflow-y-auto no-scrollbar pb-32">
      <TopBar title="Gas Suppression" subtitle={`REF: ${auditId}`} showBack />
      
      <div className="p-4 flex flex-col gap-6 animate-in fade-in duration-500">
        {/* Tab Selector */}
        <section className="bg-surface-dark p-2 rounded-2xl border border-white/5 flex gap-2 overflow-x-auto no-scrollbar shadow-lg">
           {systems.map((s, idx) => (
              <div key={s.id} className="relative shrink-0 flex items-center">
                <button 
                  onClick={() => setActiveSystemId(s.id)} 
                  className={`px-5 h-11 shrink-0 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 pr-10 ${activeSystemId === s.id ? 'bg-primary text-white shadow-lg' : 'bg-background-dark/50 text-text-muted hover:bg-white/5'}`}
                >
                  <span className="material-symbols-outlined text-sm">gas_meter</span>
                  {s.zoneName || `Zone ${idx + 1}`}
                </button>
                {systems.length > 1 && (
                  <button 
                    type="button"
                    onClick={(e) => { e.preventDefault(); e.stopPropagation(); setDeleteTarget(s); }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center text-white/30 hover:text-white transition-colors bg-white/5 hover:bg-red-500 rounded-full z-20"
                  >
                    <span className="material-symbols-outlined text-[14px]">close</span>
                  </button>
                )}
              </div>
           ))}
           <button onClick={() => { const ns = getDefaultSystem(); setSystems([...systems, ns]); setActiveSystemId(ns.id); }} className="px-4 h-11 rounded-xl bg-white/5 text-primary flex items-center justify-center shrink-0 border border-white/5"><span className="material-symbols-outlined">add</span></button>
        </section>

        {/* Section: Profile & Summary */}
        <section className="bg-primary/10 border border-primary/20 p-5 rounded-2xl flex flex-col gap-4 shadow-xl">
           <div className="flex justify-between items-center border-b border-primary/20 pb-3">
              <h3 className="text-[11px] font-black uppercase text-white tracking-widest italic">Site Audit Profile</h3>
              <select value={activeSystem.systemOverallStatus} onChange={(e) => updateActiveSystem({ systemOverallStatus: e.target.value as any })} className="bg-background-dark/50 border border-primary/40 rounded px-2 h-6 text-[8px] font-black uppercase text-white outline-none">
                <option value="Normal">Normal</option><option value="Faulty">Faulty</option>
              </select>
           </div>
           <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase ml-1">Zone Protected</label><input value={activeSystem.zoneName} onChange={(e) => updateActiveSystem({ zoneName: e.target.value })} className="bg-background-dark/50 border-white/5 border rounded-xl h-11 px-4 text-[11px] font-bold text-white outline-none focus:ring-1 focus:ring-primary" placeholder="e.g. Server Room A" /></div>
           <textarea value={activeSystem.systemDescription} onChange={(e) => updateActiveSystem({ systemDescription: e.target.value })} className="bg-background-dark/50 border-white/5 border rounded-xl p-3 text-xs font-medium h-20 text-white outline-none focus:ring-1 focus:ring-primary" placeholder="General system overview..." />
        </section>

        {/* Part I: Cylinder & Agent */}
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
           <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">settings_input_hdmi</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part I: Silinder & Agen</h3></div>
           <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="flex flex-col gap-1">
                <label className="text-[8px] font-black text-text-muted uppercase ml-1">Jenis Agen (Gas)</label>
                <select 
                  value={activeSystem.agentType} 
                  onChange={(e) => updateActiveSystem({ agentType: e.target.value })} 
                  className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-xs font-bold text-primary outline-none appearance-none"
                >
                  {gasOptions.map(opt => <option key={opt} value={opt} className="bg-surface-dark">{opt}</option>)}
                </select>
              </div>
              <div className="flex flex-col gap-1"><label className="text-[8px] font-black text-text-muted uppercase ml-1">Bilangan Tong (Qty)</label><input type="number" value={activeSystem.cylinderQty} onChange={(e) => updateActiveSystem({ cylinderQty: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-xs font-black text-white outline-none" /></div>
           </div>

           {/* Conditional fields for "Lain-lain (Others)" */}
           {activeSystem.agentType === 'Lain-lain (Others)' && (
             <div className="bg-background-dark/40 border border-primary/20 rounded-2xl p-4 mb-4 flex gap-4 animate-in slide-in-from-top duration-300">
                <div className="flex flex-col gap-1 items-center">
                   <label className="text-[7px] font-black text-primary uppercase">Bukti Gas</label>
                   <PhotoCaptureBox 
                     photo={activeSystem.otherAgentPhoto} 
                     onCapture={async (p) => {
                       const cp = await compressImage(p);
                       updateActiveSystem({ otherAgentPhoto: cp });
                     }}
                     className="w-14 h-14"
                   />
                </div>
                <div className="flex-1 flex flex-col gap-1">
                   <label className="text-[7px] font-black text-primary uppercase">Nama/Catatan Gas</label>
                   <textarea 
                     value={activeSystem.otherAgentRemark} 
                     onChange={(e) => updateActiveSystem({ otherAgentRemark: e.target.value })}
                     className="bg-background-dark/50 border-none rounded-xl p-2 text-[10px] h-14 text-white italic outline-none focus:ring-1 focus:ring-primary"
                     placeholder="Sila nyatakan jenis gas dan info tambahan..."
                   />
                </div>
             </div>
           )}

           <div className="grid grid-cols-1 gap-3 mb-3">
              <div className="flex flex-col gap-1">
                <label className="text-[8px] font-black text-text-muted uppercase ml-1">No. Siri Tong</label>
                <input value={activeSystem.cylinderSerial} onChange={(e) => updateActiveSystem({ cylinderSerial: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-[10px] font-bold text-white outline-none" placeholder="SN-XXXX" />
              </div>
           </div>

           <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center px-1">
                  <label className="text-[8px] font-black text-text-muted uppercase">Tarikh Buatan (MFG)</label>
                  <span className="text-[6px] font-black text-primary uppercase tracking-tighter">Auto-Fill Hydro</span>
                </div>
                <input type="month" value={activeSystem.cylinderMfgDate} onChange={(e) => handleMfgDateChange(e.target.value)} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-[10px] font-bold text-white outline-none border-b border-primary/20" />
              </div>
              <div className="flex flex-col gap-1">
                <div className="flex justify-between items-center px-1">
                  <label className="text-[8px] font-black text-primary uppercase">Ujian Hidro (Hydro)</label>
                  <span className="text-[6px] font-black text-emerald-500 uppercase tracking-tighter">Cycle: 10 Yrs</span>
                </div>
                <input type="month" value={activeSystem.cylinderHydroDate} onChange={(e) => updateActiveSystem({ cylinderHydroDate: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-4 text-[10px] font-bold text-emerald-500 outline-none" />
              </div>
           </div>

           <div className="grid grid-cols-3 gap-3">
              <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Timer (S)</label><input value={activeSystem.dischargeTimer} onChange={(e) => updateActiveSystem({ dischargeTimer: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-2 text-center text-xs font-black text-amber-500" /></div>
              <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Batt Volt (V)</label><input value={activeSystem.batteryVolt} onChange={(e) => updateActiveSystem({ batteryVolt: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-2 text-center text-xs font-black text-emerald-500" /></div>
              <div className="flex flex-col gap-1"><label className="text-[7px] font-black text-text-muted uppercase text-center">Chg Volt (V)</label><input value={activeSystem.chargerVolt} onChange={(e) => updateActiveSystem({ chargerVolt: e.target.value })} className="bg-background-dark/50 border-none rounded-xl h-11 px-2 text-center text-xs font-black text-blue-400" /></div>
           </div>
        </section>

        {/* Part II: Peranti Pengesanan & Penggera */}
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
           <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">grid_view</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part II: Device Condition Audit</h3></div>
           <div className="flex flex-col gap-5">
              <DeviceStatusRow 
                label="Smoke Detector" 
                qty={activeSystem.smokeQty} 
                onQtyChange={(q) => updateActiveSystem({ smokeQty: q })}
                status={activeSystem.smokeStatus}
                onToggle={(s) => updateDeviceDetail('smoke', 'status', s)}
                remark={activeSystem.deviceRemarks.smoke}
                onRemark={(r) => updateDeviceDetail('smoke', 'remark', r)}
                photo={activeSystem.devicePhotos.smoke}
                onPhoto={(p) => updateDeviceDetail('smoke', 'photo', p)}
              />
              <DeviceStatusRow 
                label="Heat Detector" 
                qty={activeSystem.heatQty} 
                onQtyChange={(q) => updateActiveSystem({ heatQty: q })}
                status={activeSystem.heatStatus}
                onToggle={(s) => updateDeviceDetail('heat', 'status', s)}
                remark={activeSystem.deviceRemarks.heat}
                onRemark={(r) => updateDeviceDetail('heat', 'remark', r)}
                photo={activeSystem.devicePhotos.heat}
                onPhoto={(p) => updateDeviceDetail('smoke', 'photo', p)}
              />
              <DeviceStatusRow 
                label="Alarm Bell" 
                qty={activeSystem.bellQty} 
                onQtyChange={(q) => updateActiveSystem({ bellQty: q })}
                status={activeSystem.bellStatus}
                onToggle={(s) => updateDeviceDetail('bell', 'status', s)}
                remark={activeSystem.deviceRemarks.bell}
                onRemark={(r) => updateDeviceDetail('bell', 'remark', r)}
                photo={activeSystem.devicePhotos.bell}
                onPhoto={(p) => updateDeviceDetail('bell', 'photo', p)}
              />
              <DeviceStatusRow 
                label="Flashing Light" 
                qty={activeSystem.flashingLightQty} 
                onQtyChange={(q) => updateActiveSystem({ flashingLightQty: q })}
                status={activeSystem.flashingLightStatus}
                onToggle={(s) => updateDeviceDetail('flashingLight', 'status', s)}
                remark={activeSystem.deviceRemarks.flashingLight}
                onRemark={(r) => updateDeviceDetail('flashingLight', 'remark', r)}
                photo={activeSystem.devicePhotos.flashingLight}
                onPhoto={(p) => updateDeviceDetail('flashingLight', 'photo', p)}
              />
              <DeviceStatusRow 
                label="Trip Blanket / Solenoid" 
                qty={activeSystem.blanketQty} 
                onQtyChange={(q) => updateActiveSystem({ blanketQty: q })}
                status={activeSystem.blanketStatus}
                onToggle={(s) => updateDeviceDetail('blanket', 'status', s)}
                remark={activeSystem.deviceRemarks.blanket}
                onRemark={(r) => updateDeviceDetail('blanket', 'remark', r)}
                photo={activeSystem.devicePhotos.blanket}
                onPhoto={(p) => updateDeviceDetail('blanket', 'photo', p)}
              />
           </div>
        </section>

        {/* Part III: Integriti Mekanikal & Kuasa */}
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
           <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">precision_manufacturing</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part III: Mechanical & Power Integrity</h3></div>
           <div className="flex flex-col gap-4">
              <SimpleStatusRow 
                label="Standby Battery Health" 
                status={activeSystem.batteryStatus}
                onToggle={(s) => updateDeviceDetail('battery', 'status', s)}
                remark={activeSystem.deviceRemarks.battery}
                onRemark={(r) => updateDeviceDetail('battery', 'remark', r)}
                photo={activeSystem.devicePhotos.battery}
                onPhoto={(p) => updateDeviceDetail('battery', 'photo', p)}
              />
              <SimpleStatusRow 
                label="Piping & Hoses" 
                status={activeSystem.pipingStatus}
                onToggle={(s) => updateDeviceDetail('piping', 'status', s)}
                remark={activeSystem.deviceRemarks.piping}
                onRemark={(r) => updateDeviceDetail('piping', 'remark', r)}
                photo={activeSystem.devicePhotos.piping}
                onPhoto={(p) => updateDeviceDetail('piping', 'photo', p)}
              />
              <SimpleStatusRow 
                label="Discharge Nozzles" 
                status={activeSystem.nozzleStatus}
                onToggle={(s) => updateDeviceDetail('nozzle', 'status', s)}
                remark={activeSystem.deviceRemarks.nozzle}
                onRemark={(r) => updateDeviceDetail('nozzle', 'remark', r)}
                photo={activeSystem.devicePhotos.nozzle}
                onPhoto={(p) => updateDeviceDetail('nozzle', 'photo', p)}
              />
           </div>
        </section>

        {/* Part IV: Integration Logic */}
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
           <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">hub</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part IV: Integration Logic</h3></div>
           <div className="flex flex-col gap-3">
              {activeSystem.integrationItems.map((ind, idx) => (
                 <div key={ind.id} className="bg-background-dark/30 p-3 rounded-xl border border-white/5">
                    <div className="flex justify-between items-center mb-2">
                       <span className="text-[9px] font-bold text-white uppercase">{ind.label}</span>
                       <div className="flex gap-1 h-7">
                          {['Functional', 'Faulty', 'N/A'].map(s => (
                             <button key={s} onClick={() => {
                                const ni = [...activeSystem.integrationItems]; ni[idx].status = s as any; updateActiveSystem({ integrationItems: ni });
                             }} className={`px-2 rounded-lg text-[7px] font-black uppercase ${ind.status === s ? (s === 'Functional' ? 'bg-emerald-600 shadow-md' : s === 'Faulty' ? 'bg-primary shadow-md' : 'bg-slate-600') + ' text-white' : 'bg-background-dark text-text-muted'}`}>{s}</button>
                          ))}
                       </div>
                    </div>
                    {ind.status === 'Faulty' ? (
                       <div className="flex gap-2 animate-in slide-in-from-top">
                          <PhotoCaptureBox photo={ind.photo} onCapture={async (p) => {
                            const cp = await compressImage(p);
                            const ni = [...activeSystem.integrationItems]; ni[idx].photo = cp; updateActiveSystem({ integrationItems: ni });
                          }} />
                          <textarea value={ind.remarks} onChange={(e) => {
                            const ni = [...activeSystem.integrationItems]; ni[idx].remarks = e.target.value; updateActiveSystem({ integrationItems: ni });
                          }} className="flex-1 bg-background-dark border-none rounded-lg p-2 text-[8px] text-white" placeholder="Describe fault..." />
                       </div>
                    ) : (
                       <input value={ind.remarks} onChange={(e) => {
                          const ni = [...activeSystem.integrationItems]; ni[idx].remarks = e.target.value; updateActiveSystem({ integrationItems: ni });
                       }} className="w-full bg-background-dark/50 border-none rounded-lg h-7 px-3 text-[8px] text-white italic outline-none" placeholder="Remark..." />
                    )}
                 </div>
              ))}
           </div>
        </section>

        {/* Service Evidence */}
        <section className="bg-surface-dark p-5 rounded-2xl border border-white/5 shadow-xl">
           <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3"><span className="material-symbols-outlined text-primary text-sm">history_edu</span><h3 className="text-[10px] font-black uppercase tracking-widest text-text-muted italic">Part V: Service Verification</h3></div>
           <textarea value={activeSystem.overallRemarks} onChange={(e) => updateActiveSystem({ overallRemarks: e.target.value })} className="w-full bg-background-dark/40 border-none rounded-2xl p-4 text-[11px] h-24 mb-4 text-white focus:ring-1 focus:ring-primary outline-none" placeholder="Summary of overall findings..." />
           <div className="grid grid-cols-4 gap-3">
              {activeSystem.servicePhotos.map((photo, idx) => (
                <PhotoCaptureBox key={idx} photo={photo} onCapture={async (p) => {
                  const cp = await compressImage(p);
                  const n = [...activeSystem.servicePhotos]; n[idx] = cp; updateActiveSystem({ servicePhotos: n });
                }} />
              ))}
           </div>
        </section>
      </div>

      {/* Delete Modal */}
      {deleteTarget && (
        <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-200">
           <div className="bg-surface-dark w-full max-sm rounded-[32px] border border-white/10 p-8 flex flex-col gap-6 shadow-2xl animate-in zoom-in-95">
              <div className="w-16 h-16 bg-red-500/20 rounded-2xl flex items-center justify-center text-red-500 mx-auto">
                 <span className="material-symbols-outlined text-3xl">delete_sweep</span>
              </div>
              <div className="text-center">
                 <h3 className="text-sm font-black uppercase tracking-widest text-white mb-2">PADAM SISTEM GAS?</h3>
                 <p className="text-[10px] text-text-muted font-bold leading-relaxed">
                    Sistem ini akan dipadam secara kekal. <br/>
                    <span className="text-white font-black">"{deleteTarget.zoneName}"</span>
                 </p>
              </div>
              <div className="flex flex-col gap-3">
                 <button onClick={executeDelete} className="w-full h-14 bg-red-600 text-white font-black uppercase tracking-widest text-xs rounded-2xl shadow-lg active:scale-95 transition-all">YA, PADAM SEKARANG</button>
                 <button onClick={() => setDeleteTarget(null)} className="w-full h-14 bg-white/5 text-text-muted font-black uppercase tracking-widest text-[10px] rounded-2xl active:scale-95 transition-all">BATALKAN</button>
              </div>
           </div>
        </div>
      )}

      <div className="fixed bottom-0 w-full max-w-md bg-surface-dark border-t border-white/5 p-5 pb-10 z-50">
         <button onClick={() => navigate(`/checklist/${auditId}`)} className="w-full h-14 bg-primary text-white font-black uppercase tracking-[0.2em] text-xs rounded-xl shadow-2xl active:scale-[0.98] transition-all flex items-center justify-center gap-2"><span>Commit Registry</span><span className="material-symbols-outlined text-sm">verified_user</span></button>
      </div>
    </div>
  );
};

const DeviceStatusRow: React.FC<any> = ({ label, qty, onQtyChange, status, onToggle, remark, onRemark, photo, onPhoto }) => {
  const isFault = status === 'Fault';
  return (
    <div className={`p-4 rounded-xl border transition-all ${isFault ? 'bg-primary/5 border-primary/20' : 'bg-background-dark/30 border-white/5'}`}>
       <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between pb-2 border-b border-white/5">
             <span className="text-[10px] font-black text-white italic uppercase">{label}</span>
             <div className="flex gap-1.5 h-7">
               {['Normal', 'Fault'].map(s => (
                 <button key={s} onClick={() => onToggle(s)} className={`px-4 rounded-lg text-[7px] font-black uppercase transition-all ${status === s ? (s === 'Normal' ? 'bg-emerald-600 shadow-md' : 'bg-primary shadow-md') + ' text-white' : 'bg-background-dark text-text-muted'}`}>{s}</button>
               ))}
             </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="flex flex-col gap-1 w-24">
                <label className="text-[7px] font-black text-text-muted uppercase ml-1">Kuantiti</label>
                <input type="number" value={qty} onChange={(e) => onQtyChange(e.target.value)} className="bg-background-dark/50 border-none rounded-lg h-9 text-center text-[10px] font-black text-white outline-none" />
             </div>
             {isFault ? (
                <div className="flex-1 flex gap-2 animate-in slide-in-from-top">
                   <PhotoCaptureBox photo={photo} onCapture={async (p) => { const cp = await compressImage(p); onPhoto(cp); }} />
                   <textarea value={remark || ''} onChange={(e) => onRemark(e.target.value)} className="flex-1 bg-background-dark/50 border-none rounded-lg p-2 text-[8px] text-white italic h-9 outline-none focus:ring-1 focus:ring-primary" placeholder="Sebab kerosakan..." />
                </div>
             ) : (
                <div className="flex-1 flex flex-col gap-1">
                   <label className="text-[7px] font-black text-text-muted uppercase ml-1">Catatan</label>
                   <input value={remark || ''} onChange={(e) => onRemark(e.target.value)} className="w-full bg-background-dark/50 border-none rounded-lg h-9 px-3 text-[8px] text-white italic outline-none" placeholder="Info tambahan..." />
                </div>
             )}
          </div>
       </div>
    </div>
  );
};

const SimpleStatusRow: React.FC<any> = ({ label, status, onToggle, remark, onRemark, photo, onPhoto }) => {
  const isFault = status === 'Fault';
  return (
    <div className={`p-4 rounded-xl border transition-all ${isFault ? 'bg-primary/5 border-primary/20' : 'bg-background-dark/30 border-white/5'}`}>
       <div className="flex items-center justify-between mb-2">
          <span className="text-[9px] font-black text-white italic uppercase">{label}</span>
          <div className="flex gap-1.5 h-7">
             {['Normal', 'Fault'].map(s => (
                <button key={s} onClick={() => onToggle(s)} className={`px-4 rounded-lg text-[7px] font-black uppercase transition-all ${status === s ? (s === 'Normal' ? 'bg-emerald-600 shadow-md' : 'bg-primary shadow-md') + ' text-white' : 'bg-background-dark text-text-muted'}`}>{s}</button>
             ))}
          </div>
       </div>
       {isFault ? (
          <div className="flex gap-2 animate-in slide-in-from-top">
             <PhotoCaptureBox photo={photo} onCapture={async (p) => { const cp = await compressImage(p); onPhoto(cp); }} />
             <textarea value={remark || ''} onChange={(e) => onRemark(e.target.value)} className="flex-1 bg-background-dark/50 border-none rounded-lg p-2 text-[8px] text-white italic h-10 outline-none focus:ring-1 focus:ring-primary" placeholder="Sebab kerosakan..." />
          </div>
       ) : (
          <input value={remark || ''} onChange={(e) => onRemark(e.target.value)} className="w-full bg-background-dark/50 border-none rounded-lg h-7 px-3 text-[8px] text-white italic outline-none" placeholder="Catatan integriti..." />
       )}
    </div>
  );
};

const PhotoCaptureBox: React.FC<{ photo?: string; onCapture: (p: string) => void; className?: string }> = ({ photo, onCapture, className }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => onCapture(reader.result as string);
      reader.readAsDataURL(file);
    }
  };
  return (
    <div onClick={() => fileRef.current?.click()} className={`bg-background-dark rounded-xl border border-primary/20 flex items-center justify-center overflow-hidden cursor-pointer relative group transition-all hover:border-primary/50 shadow-inner ${className || 'w-10 h-10'}`}>
      {photo ? <img src={photo} className="w-full h-full object-cover" /> : <span className="material-symbols-outlined text-primary text-sm">add_a_photo</span>}
      <input type="file" ref={fileRef} className="hidden" accept="image/*" onChange={handleFile} />
    </div>
  );
};

export default GasSuppression;
